                        const Discord = require('discord.js');
                        const { Database } = require('st.db');
                        const { Client, MessageActionRow, MessageButton } = require('discord.js');
                        const db3 = new Database('/Json-db/Others/Bots-Price.json');
                        const DB = require('../../Schema/Coins/users');
                        
                        module.exports = {
                            name: 'Feedback_Continue',
                            aliases: ['', ''],
                            description: '',
                            usage: [''],
                            botPermission: [''],
                            authorPermission: [''],
                            cooldowns: [],
                            ownerOnly: false,
                            run: async (client, interaction, args, config) => {
                                try {
                                    const FeedbackPrice = db3.get(`FeedbackP_${interaction.guild.id}`) || db3.get('FeedbackP') || 1;
                        
                                    const userId = interaction.user.id;
                                    const user = await DB.findOne({ userid: userId });
                        
                                    if (user) {
                                        const currentBalance = user.balance;
                        
                                        if (currentBalance >= FeedbackPrice) {
                                            // If the balance is sufficient for deduction
                                            const newBalance = currentBalance - FeedbackPrice;
                                            user.balance = newBalance;
                                            await user.save();
                        
                                            const Feedback_Button = new MessageActionRow().addComponents(
                                                new MessageButton()
                                                    .setCustomId('BuyFeedback')
                                                    .setLabel('Feedback')
                                                    .setStyle('PRIMARY')
                                            );
                        
                                            await interaction.channel.send({ components: [Feedback_Button] });
                                        } else {
                                            // If the balance is insufficient for deduction
                                            await interaction.reply({ content: '**رصيدك غير كاف ❌**', ephemeral: true });
                                        }
                                    } else {
                                        await interaction.reply({ content: '**User not found ❌**', ephemeral: true });
                                    }
                                } catch (error) {
                                    console.error(error);
                                }
                            },
                        };
                        