const Discord = require('discord.js');
const { Database } = require('st.db');
const { Client, MessageActionRow, MessageButton } = require('discord.js');
const db3 = new Database('/Json-db/Others/Bots-Price.json');
const DB = require('../../Schema/Coins/users');

module.exports = {
    name: 'Ticket_Continue',
    aliases: ['', ''],
    description: '',
    usage: [''],
    botPermission: [''],
    authorPermission: [''],
    cooldowns: [],
    ownerOnly: false,
    run: async (client, interaction, args, config) => {
        try {
            const TicketPrice = db3.get(`TicketP_${interaction.guild.id}`) || db3.get('TicketP') || 1;

            const userId = interaction.user.id;
            const user = await DB.findOne({ userid: userId });

            if (user) {
                const currentBalance = user.balance;

                if (currentBalance >= TicketPrice) {
                    // If the balance is sufficient for deduction
                    const newBalance = currentBalance - TicketPrice;
                    user.balance = newBalance;
                    await user.save();

                    const Ticket_BUTTON = new MessageActionRow().addComponents(
                        new MessageButton()
                            .setCustomId('BuyTicket')
                            .setLabel('Ticket')
                            .setStyle('PRIMARY')
                    );

                    await interaction.channel.send({ components: [Ticket_BUTTON] });
                } else {
                    // If the balance is insufficient for deduction
                    await interaction.reply({ content: '**رصيدك غير كاف ❌**', ephemeral: true });
                }
            } else {
                await interaction.reply({ content: '**User not found ❌**', ephemeral: true });
            }
        } catch (error) {
            console.error(error);
        }
    },
};
