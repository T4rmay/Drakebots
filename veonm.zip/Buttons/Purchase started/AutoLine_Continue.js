const Discord = require('discord.js');
const { Database } = require('st.db');
const { Client, MessageActionRow, MessageButton } = require('discord.js');
const db3 = new Database('/Json-db/Others/Bots-Price.json');
const DB = require('../../Schema/Coins/users');

module.exports = {
    name: 'AutoLine_Continue',
    aliases: ['', ''],
    description: '',
    usage: [''],
    botPermission: [''],
    authorPermission: [''],
    cooldowns: [],
    ownerOnly: false,
    run: async (client, interaction, args, config) => {
        try {
            const AutolinePrice = db3.get(`AutolineP_${interaction.guild.id}`) || db3.get('AutolineP') || 1;

            const userId = interaction.user.id;
            const user = await DB.findOne({ userid: userId });

            if (user) {
                const currentBalance = user.balance;

                if (currentBalance >= AutolinePrice) {
                    // If the balance is sufficient for deduction
                    const newBalance = currentBalance - AutolinePrice;
                    user.balance = newBalance;
                    await user.save();

                    const Autoline_BUTTON = new MessageActionRow().addComponents(
                        new MessageButton()
                            .setCustomId('BuyAutoLine')
                            .setLabel('Auto-line')
                            .setStyle('PRIMARY')
                    );

                    await interaction.channel.send({ components: [Autoline_BUTTON] });
                } else {
                    // If the balance is insufficient for deduction
                    await interaction.reply({ content: '**رصيدك غير كاف ❌**', ephemeral: true });
                }
            } else {
                await interaction.reply({ content: '**User not found ❌**', ephemeral: true });
            }
        } catch (error) {
            console.error(error);
        }
    },
};
