const Discord = require('discord.js');
const { Database } = require('st.db');
const { Client, MessageActionRow, MessageButton } = require('discord.js');
const db3 = new Database('/Json-db/Others/Bots-Price.json');
const DB = require('../../Schema/Coins/users');

module.exports = {
    name: 'System_Continue',
    aliases: ['', ''],
    description: '',
    usage: [''],
    botPermission: [''],
    authorPermission: [''],
    cooldowns: [],
    ownerOnly: false,
    run: async (client, interaction, args, config) => {
        try {
            const SystemPrice = db3.get(`SystemP_${interaction.guild.id}`) || db3.get('SystemP') || 1;

            const userId = interaction.user.id;
            const user = await DB.findOne({ userid: userId });

            if (user) {
                const currentBalance = user.balance;

                if (currentBalance >= SystemPrice) {
                    // If the balance is sufficient for deduction
                    const newBalance = currentBalance - SystemPrice;
                    user.balance = newBalance;
                    await user.save();

                    const System_Button = new MessageActionRow().addComponents(
                        new MessageButton()
                            .setCustomId('BuySystem')
                            .setLabel('System')
                            .setStyle('PRIMARY')
                    );

                    await interaction.channel.send({ components: [System_Button] });
                } else {
                    // If the balance is insufficient for deduction
                    await interaction.reply({ content: '**رصيدك غير كاف ❌**', ephemeral: true });
                }
            } else {
                await interaction.reply({ content: '**User not found ❌**', ephemeral: true });
            }
        } catch (error) {
            console.error(error);
        }
    },
};
