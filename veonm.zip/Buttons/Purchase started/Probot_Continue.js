const Discord = require('discord.js');
const { Database } = require('st.db');
const { Client, MessageActionRow, MessageButton } = require('discord.js');
const db3 = new Database('/Json-db/Others/Bots-Price.json');
const DB = require('../../Schema/Coins/users');

module.exports = {
    name: 'Probot_Continue',
    aliases: ['', ''],
    description: '',
    usage: [''],
    botPermission: [''],
    authorPermission: [''],
    cooldowns: [],
    ownerOnly: false,
    run: async (client, interaction, args, config) => {
        try {
            const ProbotPrice = db3.get(`ProbotP_${interaction.guild.id}`) || db3.get('ProbotP') || 1;

            const userId = interaction.user.id;
            const user = await DB.findOne({ userid: userId });

            if (user) {
                const currentBalance = user.balance;

                if (currentBalance >= ProbotPrice) {
                    // If the balance is sufficient for deduction
                    const newBalance = currentBalance - ProbotPrice;
                    user.balance = newBalance;
                    await user.save();

                    const Probot_Button = new MessageActionRow().addComponents(
                        new MessageButton()
                            .setCustomId('BuyProbot')
                            .setLabel('Probot')
                            .setStyle('PRIMARY')
                    );

                    await interaction.channel.send({ components: [Probot_Button] });
                } else {
                    // If the balance is insufficient for deduction
                    await interaction.reply({ content: '**رصيدك غير كاف ❌**', ephemeral: true });
                }
            } else {
                await interaction.reply({ content: '**User not found ❌**', ephemeral: true });
            }
        } catch (error) {
            console.error(error);
        }
    },
};
