const { SlashCommandBuilder } = require("@discordjs/builders");
const { Database } = require("st.db");
const db = require('../../Schema/Coins/users');
const BOTMAKETDB = new Database('/Json-db/BotMaker/BOTMAKERDB.json');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('buy-coins')
        .setDescription('شراء عملات بالكريديت')
        .addIntegerOption(option => option.setName('coins').setDescription('عدد العملات').setRequired(true)),

    run: async (client, interaction, args) => {
        const Price = BOTMAKETDB.get(`Price_${interaction.guild.id}`);
        const balance = interaction.options.getInteger('coins');
        const price = balance * Price;
        const tax = Math.floor(price * (20 / 19) + 1);
        const Owner = BOTMAKETDB.get(`trID_${interaction.guild.id}`);
        const ProbotID = BOTMAKETDB.get(`probotID_${interaction.guild.id}`);

        interaction.reply({ content: `\`\`\`#credit ${Owner} ${tax}\`\`\`` }).then(async (msg) => {
            try {
                const collected = await interaction.channel.awaitMessages({
                    filter: ({ content, author: { id } }) => {
                        return content.startsWith(`**:moneybag: | ${interaction.user.username}, has transferred `) &&
                            content.includes(`${Owner}`) &&
                            id === `${ProbotID}` &&
                            (Number(content.slice(content.lastIndexOf("`") - String(tax).length, content.lastIndexOf("`"))) >= price);
                    },
                    max: 1,
                    time: 60000,
                    errors: ['time']
                });

                if (collected.size > 0) {
                    const response = collected.first();
                    const userBalance = await db.findOne({ userid: interaction.user.id });

                    if (userBalance) {
                        const updatedBalance = parseInt(userBalance.balance) + parseInt(balance);
                        await db.findOneAndUpdate({ userid: interaction.user.id }, { balance: updatedBalance });
                    } else {
                        const count = parseInt(balance);
                        const newUser = new db({
                            userid: interaction.user.id,
                            balance: count,
                        });
                        await newUser.save();
                    }

                    interaction.editReply({ content: `**لقد قام ${interaction.user} بشراء ${balance} عملة** :coin:` });

                    response.delete();
                }
            } catch (error) {
                interaction.editReply({ content: `**انتهى الوقت لا تقم بالتحويل ** ${interaction.user}` });
            }
        });
    },
};
