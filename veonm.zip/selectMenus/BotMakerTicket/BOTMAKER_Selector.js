const Discord = require('discord.js')
const {
  Client,
  Collection,
  MessageActionRow,
  MessageButton,
  MessageEmbed,
  MessageSelectMenu,
  Intents,
  Modal,
  TextInputComponent
} = require("discord.js");
const { type } = require('os');

const { Database } = require("st.db")
const ticketdb3 = new Database("/Json-db/Others/ticket-Number.json");
const BOTMAKETDB = new Database("/Json-db/BotMaker/BOTMAKERDB");
const db6 = new Database("/Json-db/Others/bots-statusdb.json");
const {CoderServer} = require(`../../config.json`)
const db = new Database("/Json-db/BotMaker/BOTMAKERDB.json")
const db3 = new Database('/Json-db/Others/Bots-Price.json');

module.exports = {
  name: "BOTMAKER_Selector",
  description: "",
  usage: [""],
  botPermission: ["MANAGE_CHANNELS"],
  authorPermission: [""],
  cooldowns: [0],
  ownerOnly: false,
  run: async (client, interaction, args, config) => {
    try {
      interaction.reply({content:`[!] Please wait.`,ephemeral: true})
      const Selected = interaction.values[0];
      if (Selected === 'Reset_Selected') {
        if (interaction.replied) {
          return;
        } else {
          try {
            if (!interaction.replied) {
             interaction.update()
            }

          } catch (error) {
            
          }
        }
      }else if (Selected === `Autoline_Selected`) {
        const Type = `Auto-line`//تعديل
        try {
          const autolinestatus = db6.get(`Autoline`) || "1";//تعديل
          if (autolinestatus === "0") {//تعديل
            return await interaction.editReply({content:`***لا تستطيع شراء هذا البوت في الوقت الحالي***
              **تستطيع ان تحاول مره ثانيه عندما يكون متوفر**`,ephemeral: true,
            });
          }
          if (!interaction.guild.me.permissions.has('ADMINISTRATOR')) return i.reply({
            content: `I dont have permissions`,
            ephemeral: true,
          })
          const user = interaction.user.id
          const ticketnumber =
            ticketdb3.get(`BOTMAKERORDERNUMBER_${interaction.guild.id}`) || 1;
          const data = BOTMAKETDB.get(`BotMakerTicket_${interaction.guild.id}`);
  
          const ticketcategory = data.Category;
          const category = interaction.guild.channels.cache.find(
            (c) => c.id === `${ticketcategory}` && c.type === "GUILD_CATEGORY"
          );
          const AutolinePrice = db3.get(`AutolineP_${interaction.guild.id}`) || db3.get('AutolineP') || 1;
          const welcomeMSG = new Discord.MessageEmbed()
            .setColor(interaction.guild.me.displayHexColor)
            .setTitle(`شراء بوت خط تلقائي`)
            .setImage('https://cdn.discordapp.com/attachments/1184549472911499324/1193274640970297394/Picsart_24-01-06_21-24-29-277.jpg?ex=65ac1e9c&is=6599a99c&hm=e5445408864017021448833b97975ab4b3fee2ba2428060e75f6685897d002b8&')
            .setDescription( 
              `**## * سعر البوت  : ${AutolinePrice} <:emoji_2:1191103694297636965> 

## * اضغط على شراء لتأكيد عملية الشراء

## * لاتنسى تفعيل الثلاث خيارات للبوت الخاص بك 
**
`
            );
  
          const OrderButtons = new MessageActionRow().addComponents([
            new MessageButton()
              .setCustomId(`BOTMAKER_Close`) //تعديل
              .setStyle(`DANGER`)
              .setLabel(`اغلاق`)
             .setEmoji('❌') .setDisabled(false),
            new MessageButton()
              .setCustomId(`AutoLine_Continue`) //تعديل
              .setStyle(`SUCCESS`)
              .setLabel("شراء")
              .setEmoji('🛒')
              .setDisabled(false),

          ]);
          const channel = await interaction.guild.channels.create(`خط تلقائي-${ticketnumber}`, {
            type: "text",
            parent: category,
            permissionOverwrites: [
              {
                id: interaction.guild.roles.everyone.id,
                deny: ["VIEW_CHANNEL"],
              },
              {
                id: `${user}`,
                allow: ["VIEW_CHANNEL"],
              },
            ],
            topic: `${user}`,
          });
          await interaction.editReply({
        content: `تم فتح تكت شراء بوت : ${channel}`,
        ephemeral: true,
        })
        .catch((err) => console.log(err));
          ticketdb3.set(
            `BOTMAKERORDERNUMBER_${interaction.guild.id}`,
            parseInt(ticketnumber + 1)
          );
           channel.send({
            content: `<@${interaction.user.id}>`,
            embeds: [welcomeMSG],
            components: [OrderButtons],
          });
        } catch (error) {
          console.log(error)
        }
      }else if(Selected === `Suggestion_Selected`){
        const Type = `Suggestion`
        try {
          const suggestionstatus = db6.get(`Suggestion`) || "1";
          if (suggestionstatus === "0") {//تعديل
            return await interaction.editReply({content:`***لا تستطيع شراء هذا البوت في الوقت الحالي***
            **تستطيع ان تحاول مره ثانيه عندما يكون متوفر**`,ephemeral: true,
          });
          }
          if(!interaction.guild.me.permissions.has('ADMINISTRATOR')) return i.reply({
            content: `I dont have permissions`,
            ephemeral: true,
            })
        const user = interaction.user.id
        const ticketnumber =
        ticketdb3.get(`BOTMAKERORDERNUMBER_${interaction.guild.id}`) || 1;
        const data = BOTMAKETDB.get(`BotMakerTicket_${interaction.guild.id}`);
        
        const ticketcategory = data.Category;
        const category = interaction.guild.channels.cache.find(
        (c) => c.id === `${ticketcategory}` && c.type === "GUILD_CATEGORY"
        );
        const SuggestionPrice = db3.get(`SuggestionP_${interaction.guild.id}`) || db3.get('SuggestionP') || 1;
        const welcomeMSG = new Discord.MessageEmbed()
        .setColor(interaction.guild.me.displayHexColor)
        .setTitle(`شراء بوت اقتراحات`)
            .setImage('https://cdn.discordapp.com/attachments/1184549472911499324/1193274626365739078/Picsart_24-01-06_21-24-40-583.jpg?ex=65ac1e98&is=6599a998&hm=437636f904d1af2ea1e9b2f262a1f026f13b942d53d0469b9fa5992e427446fd&')
            .setDescription( 
              `**## * سعر البوت: ${SuggestionPrice} <:emoji_2:1191103694297636965>

## * اضغط على شراء لتأكيد عملية الشراء

## * لاتنسى تفعيل الثلاث خيارات للبوت الخاص بك 

**`
            );
        
        const OrderButtons = new MessageActionRow().addComponents([
        new MessageButton()
        .setCustomId(`BOTMAKER_Close`) //تعديل
        .setStyle(`DANGER`)
        .setLabel(`اغلاق`)
        .setEmoji('❌')
        .setDisabled(false),
        new MessageButton()
        .setCustomId(`Suggestion_Continue`) //تعديل
        .setStyle(`SUCCESS`)
        .setLabel("شراء")
        .setEmoji('🛒')
        .setDisabled(false),
        ]);
        
        const channel = await interaction.guild.channels.create(`اقتراحات-${ticketnumber}`, {
        type: "text",
        parent: category,
        permissionOverwrites: [
        {
        id: interaction.guild.roles.everyone.id,
        deny: ["VIEW_CHANNEL"],
        },
        {
        id: `${user}`,
        allow: ["VIEW_CHANNEL"],
        },
        ],
        topic: `${user}`,
        });
        await interaction.editReply({
        content: `تم فتح تكت شراء بوت : ${channel}`,
        ephemeral: true,
        })
        .catch((err) => console.log(err));
        ticketdb3.set(
        `BOTMAKERORDERNUMBER_${interaction.guild.id}`,
        parseInt(ticketnumber + 1)
        );
         channel.send({
        content: `<@${interaction.user.id}>`,
        embeds: [welcomeMSG],
        components: [OrderButtons],
        });
        } catch (error) {
          console.log(error)
        }
      }else if(Selected === `Tax_Selected`){
        const Type = `Auto-Tax`
        try {
          const taxstatus = db6.get(`Tax`) || "1";
          if (taxstatus === "0") {//تعديل
            return await interaction.editReply({content:`***لا تستطيع شراء هذا البوت في الوقت الحالي***
            **تستطيع ان تحاول مره ثانيه عندما يكون متوفر**`,ephemeral: true,
          });
          }
          if(!interaction.guild.me.permissions.has('ADMINISTRATOR')) return i.reply({
            content: `I dont have permissions`,
            ephemeral: true,
            })
        const user = interaction.user.id
        const ticketnumber =
        ticketdb3.get(`BOTMAKERORDERNUMBER_${interaction.guild.id}`) || 1;
        const data = BOTMAKETDB.get(`BotMakerTicket_${interaction.guild.id}`);
        
        const ticketcategory = data.Category;
        const category = interaction.guild.channels.cache.find(
        (c) => c.id === `${ticketcategory}` && c.type === "GUILD_CATEGORY"
        );
        const TaxPrice = db3.get(`TaxP_${interaction.guild.id}`) || db3.get('TaxP') || 1;
        const welcomeMSG = new Discord.MessageEmbed()
        .setColor(interaction.guild.me.displayHexColor)
        .setTitle(`شراء بوت ضريبه بروبوت`)
            .setImage('https://cdn.discordapp.com/attachments/1184549472911499324/1193274640181776487/Picsart_24-01-06_21-25-00-311.jpg?ex=65ac1e9c&is=6599a99c&hm=241bc486215ca1698253972ca7ab365caf57fe2bf781a6e69cddb5e1df70268f&')
            .setDescription( 
              `**## * سعر البوت: ${TaxPrice} <:emoji_2:1191103694297636965>

## * اضغط على شراء لتأكيد عملية الشراء

## * لاتنسى تفعيل الثلاث خيارات للبوت الخاص بك 

**`
            );
        
        const OrderButtons = new MessageActionRow().addComponents([
        new MessageButton()
        .setCustomId(`BOTMAKER_Close`) //تعديل
        .setStyle(`DANGER`)
        .setLabel(`اغلاق`)
        .setEmoji('❌')
        .setDisabled(false),
        new MessageButton()
        .setCustomId(`Tax_Continue`) //تعديل
        .setStyle(`SUCCESS`)
        .setLabel("شراء")
        .setEmoji('🛒')
        .setDisabled(false),
        ]);
        
        const channel = await interaction.guild.channels.create(`ضريبه بروبوت-${ticketnumber}`, {
        type: "text",
        parent: category,
        permissionOverwrites: [
        {
        id: interaction.guild.roles.everyone.id,
        deny: ["VIEW_CHANNEL"],
        },
        {
        id: `${user}`,
        allow: ["VIEW_CHANNEL"],
        },
        ],
        topic: `${user}`,
        });
        await interaction.editReply({
        content: `تم فتح تكت شراء بوت : ${channel}`,
        ephemeral: true,
        })
        .catch((err) => console.log(err));
        ticketdb3.set(
        `BOTMAKERORDERNUMBER_${interaction.guild.id}`,
        parseInt(ticketnumber + 1)
        );
        channel.send({
        content: `<@${interaction.user.id}>`,
        embeds: [welcomeMSG],
        components: [OrderButtons],
        });
        } catch (error) {
          console.log(error)
        }
      }else if(Selected === `Credit_Selected`){
        const Type = `Credits`
        try {
          const creditstatus = db6.get(`Credit`) || "1";
          if (creditstatus === "0") {//تعديل
            return await interaction.editReply({content:`***لا تستطيع شراء هذا البوت في الوقت الحالي***
            **تستطيع ان تحاول مره ثانيه عندما يكون متوفر**`,ephemeral: true,
          });
          }
          if(!interaction.guild.me.permissions.has('ADMINISTRATOR')) return i.reply({
            content: `I dont have permissions`,
            ephemeral: true,
            })
        const user = interaction.user.id
        const ticketnumber =
        ticketdb3.get(`BOTMAKERORDERNUMBER_${interaction.guild.id}`) || 1;
        const data = BOTMAKETDB.get(`BotMakerTicket_${interaction.guild.id}`);
        
        const ticketcategory = data.Category;
        const category = interaction.guild.channels.cache.find(
        (c) => c.id === `${ticketcategory}` && c.type === "GUILD_CATEGORY"
        );
        const FeedbackPrice = db3.get(`BankP${interaction.guild.id}`) || db3.get('BankP') || 1;
        const welcomeMSG = new Discord.MessageEmbed()
        .setColor(interaction.guild.me.displayHexColor)
        .setTitle(`شراء بوت كريدت وهمي`)
            .setImage('https://cdn.discordapp.com/attachments/1184549472911499324/1193274640672489605/Picsart_24-01-06_21-25-16-253.jpg?ex=65ac1e9c&is=6599a99c&hm=61a31f6d15132fc09af51b51d287dc97e94744fca6dfaa6837aa036ecdf4c0b6&')
            .setDescription( 
              `**## * سعر البوت: ${FeedbackPrice} <:emoji_2:1191103694297636965>

## * اضغط على شراء لتأكيد عملية الشراء

## * لاتنسى تفعيل الثلاث خيارات للبوت الخاص بك 

**`
            );
        
        const OrderButtons = new MessageActionRow().addComponents([
        new MessageButton()
        .setCustomId(`BOTMAKER_Close`) //تعديل
        .setStyle(`DANGER`)
        .setLabel(`اغلاق`)
        .setEmoji('❌')
        .setDisabled(false),
        new MessageButton()
        .setCustomId(`Credit_Continue`) //تعديل
        .setStyle(`SUCCESS`)
        .setLabel("شراء")
        .setEmoji('🛒')
        .setDisabled(false),
        ]);
        
        const channel = await interaction.guild.channels.create(`كريدت وهمي-${ticketnumber}`, {
        type: "text",
        parent: category,
        permissionOverwrites: [
        {
        id: interaction.guild.roles.everyone.id,
        deny: ["VIEW_CHANNEL"],
        },
        {
        id: `${user}`,
        allow: ["VIEW_CHANNEL"],
        },
        ],
        topic: `${user}`,
        });
        await interaction.editReply({
        content: `تم فتح تكت شراء بوت : ${channel}`,
        ephemeral: true,
        })
        .catch((err) => console.log(err));
        ticketdb3.set(
        `BOTMAKERORDERNUMBER_${interaction.guild.id}`,
        parseInt(ticketnumber + 1)
        );
         channel.send({
        content: `<@${interaction.user.id}>`,
        embeds: [welcomeMSG],
        components: [OrderButtons],
        });

        } catch (error) {
          console.log(error)
        }
      }else if(Selected === `Ticket_Selected`){
        const Type = `Ticket`
        try {
          const ticketstatus = db6.get(`Ticket`) || "1";
          if (ticketstatus === "0") {//تعديل
            return await interaction.editReply({content:`***لا تستطيع شراء هذا البوت في الوقت الحالي***
            **تستطيع ان تحاول مره ثانيه عندما يكون متوفر**`,ephemeral: true,
          });
          }
          if(!interaction.guild.me.permissions.has('ADMINISTRATOR')) return i.reply({
            content: `I dont have permissions`,
            ephemeral: true,
            })
        const user = interaction.user.id
        const ticketnumber =
        ticketdb3.get(`BOTMAKERORDERNUMBER_${interaction.guild.id}`) || 1;
        const data = BOTMAKETDB.get(`BotMakerTicket_${interaction.guild.id}`);
        
        const ticketcategory = data.Category;
        const category = interaction.guild.channels.cache.find(
        (c) => c.id === `${ticketcategory}` && c.type === "GUILD_CATEGORY"
        );
        const TicketPrice = db3.get(`TicketP_${interaction.guild.id}`) || db3.get('TicketP') || 1;
        const welcomeMSG = new Discord.MessageEmbed()
        .setColor(interaction.guild.me.displayHexColor)
        .setTitle(`شراء بوت تكت مطور`)
            .setImage('https://cdn.discordapp.com/attachments/1184549472911499324/1193274625531072572/Picsart_24-01-06_21-25-29-051.jpg?ex=65ac1e98&is=6599a998&hm=b56070a1b7fcfe5f21e7bd249c077f94b6a0593d8ca23a2b449d10322a40527f&')
            .setDescription( 
              `**## * سعر البوت: ${TicketPrice} <:emoji_2:1191103694297636965>

## * اضغط على شراء لتأكيد عملية الشراء

## * لاتنسى تفعيل الثلاث خيارات للبوت الخاص بك 

**`
            );
        
        const OrderButtons = new MessageActionRow().addComponents([
        new MessageButton()
        .setCustomId(`BOTMAKER_Close`) //تعديل
        .setStyle(`DANGER`)
        .setLabel(`اغلاق`)
        .setEmoji('❌')
        .setDisabled(false),
        new MessageButton()
        .setCustomId(`Ticket_Continue`) //تعديل
        .setStyle(`SUCCESS`)
        .setLabel("شراء")
        .setEmoji('🛒')
        .setDisabled(false),
        ]);
        
        const channel = await interaction.guild.channels.create(`تكت مطور-${ticketnumber}`, {
        type: "text",
        parent: category,
        permissionOverwrites: [
        {
        id: interaction.guild.roles.everyone.id,
        deny: ["VIEW_CHANNEL"],
        },
        {
        id: `${user}`,
        allow: ["VIEW_CHANNEL"],
        },
        ],
        topic: `${user}`,
        });
        await interaction.editReply({
        content: `تم فتح تكت شراء بوت : ${channel}`,
        ephemeral: true,
        })
        .catch((err) => console.log(err));
        ticketdb3.set(
        `BOTMAKERORDERNUMBER_${interaction.guild.id}`,
        parseInt(ticketnumber + 1)
        );
         channel.send({
        content: `<@${interaction.user.id}>`,
        embeds: [welcomeMSG],
        components: [OrderButtons],
        });
        } catch (error) {
          console.log(error)
        }
      }else if(Selected === `System_Selected`){
        const Type = `System`
        try {
          const systemstatus = db6.get(`System`) || "1";
          if (systemstatus === "0") {//تعديل
            return await interaction.editReply({content:`***لا تستطيع شراء هذا البوت في الوقت الحالي***
            **تستطيع ان تحاول مره ثانيه عندما يكون متوفر**`,ephemeral: true,
          });
          }
          if(!interaction.guild.me.permissions.has('ADMINISTRATOR')) return i.reply({
            content: `I dont have permissions`,
            ephemeral: true,
            })
        const user = interaction.user.id
        const ticketnumber =
        ticketdb3.get(`BOTMAKERORDERNUMBER_${interaction.guild.id}`) || 1;
        const data = BOTMAKETDB.get(`BotMakerTicket_${interaction.guild.id}`);
        
        const ticketcategory = data.Category;
        const category = interaction.guild.channels.cache.find(
        (c) => c.id === `${ticketcategory}` && c.type === "GUILD_CATEGORY"
        );
        const SystemPrice = db3.get(`SystemP_${interaction.guild.id}`) || db3.get('SystemP') || 1;
        const welcomeMSG = new Discord.MessageEmbed()
        .setColor(interaction.guild.me.displayHexColor)
        .setTitle(`شراء بوت سيستم`)
            .setImage('https://cdn.discordapp.com/attachments/1184549472911499324/1193274625820467340/Picsart_24-01-06_21-25-36-987.jpg?ex=65ac1e98&is=6599a998&hm=390360638397b37522c6b76cbf30cc1fc3f2aa4a0c6e2bf10f5010d28e3171e0&')
            .setDescription( 
              `**## * سعر البوت: ${SystemPrice} <:emoji_2:1191103694297636965>

## * اضغط على شراء لتأكيد عملية الشراء

## * لاتنسى تفعيل الثلاث خيارات للبوت الخاص بك 

**`
            );
        
        const OrderButtons = new MessageActionRow().addComponents([
        new MessageButton()
        .setCustomId(`BOTMAKER_Close`) //تعديل
        .setStyle(`DANGER`)
        .setLabel(`اغلاق`)
        .setEmoji('❌')
        .setDisabled(false),
        new MessageButton()
        .setCustomId(`System_Continue`) //تعديل
        .setStyle(`SUCCESS`)
        .setLabel("شراء")
        .setEmoji('🛒')
        .setDisabled(false),
        ]);
        
        const channel = await interaction.guild.channels.create(`سيستم-${ticketnumber}`, {
        type: "text",
        parent: category,
        permissionOverwrites: [
        {
        id: interaction.guild.roles.everyone.id,
        deny: ["VIEW_CHANNEL"],
        },
        {
        id: `${user}`,
        allow: ["VIEW_CHANNEL"],
        },
        ],
        topic: `${user}`,
        });
        await interaction.editReply({
        content: `تم فتح تكت شراء بوت : ${channel}`,
        ephemeral: true,
        })
        .catch((err) => console.log(err));
        ticketdb3.set(
        `BOTMAKERORDERNUMBER_${interaction.guild.id}`,
        parseInt(ticketnumber + 1)
        );
         channel.send({
        content: `<@${interaction.user.id}>`,
        embeds: [welcomeMSG],
        components: [OrderButtons],
        });
        } catch (error) {
          console.log(error)
        }
      }else if(Selected === `Brodcast_Selected`){
        const Type = `Brodcast`
        try {
          const brodcaststatus = db6.get(`Brodcast`) || "1";
          if (brodcaststatus === "0") {//تعديل
            return await interaction.editReply({content:`***لا تستطيع شراء هذا البوت في الوقت الحالي***
            **تستطيع ان تحاول مره ثانيه عندما يكون متوفر**`,ephemeral: true,
          });
          }
          if(!interaction.guild.me.permissions.has('ADMINISTRATOR')) return i.reply({
            content: `I dont have permissions`,
            ephemeral: true,
            })
        const user = interaction.user.id
        const ticketnumber =
        ticketdb3.get(`BOTMAKERORDERNUMBER_${interaction.guild.id}`) || 1;
        const data = BOTMAKETDB.get(`BotMakerTicket_${interaction.guild.id}`);
        
        const ticketcategory = data.Category;
        const category = interaction.guild.channels.cache.find(
        (c) => c.id === `${ticketcategory}` && c.type === "GUILD_CATEGORY"
        );
        
        const welcomeMSG = new Discord.MessageEmbed()
        .setColor(interaction.guild.me.displayHexColor)
.setTitle(`شراء بوت بروكاست`)
        .setImage('https://cdn.discordapp.com/attachments/1184549472911499324/1193274626097287311/Picsart_24-01-06_21-25-48-500.jpg?ex=65ac1e98&is=6599a998&hm=4201f4125680007f7f2ebf2f2a684be8f4224785b2c67809fbad0f4c479c8fdd&')
        .setDescription(
        `**## * سعر البوت: 2 <:emoji_2:1191103694297636965>

## * اضغط على شراء لتأكيد عملية الشراء

## * لاتنسى تفعيل الثلاث خيارات للبوت الخاص بك 

**`
        );
        
        const OrderButtons = new MessageActionRow().addComponents([
        new MessageButton()
        .setCustomId(`BOTMAKER_Close`) //تعديل
        .setStyle(`DANGER`)
        .setLabel(`اغلاق`)
        .setEmoji('❌')
        .setDisabled(false),
        new MessageButton()
        .setCustomId(`Brodcast_Continue`) //تعديل
        .setStyle(`SUCCESS`)
        .setLabel("شراء")
        .setEmoji('🛒')
        .setDisabled(false),
        ]);
        
        const channel = await interaction.guild.channels.create(`بروكاست-${ticketnumber}`, {
        type: "text",
        parent: category,
        permissionOverwrites: [
        {
        id: interaction.guild.roles.everyone.id,
        deny: ["VIEW_CHANNEL"],
        },
        {
        id: `${user}`,
        allow: ["VIEW_CHANNEL"],
        },
        ],
        topic: `${user}`,
        });
        await interaction.editReply({
        content: `تم فتح تكت شراء بوت : ${channel}`,
        ephemeral: true,
        })
        .catch((err) => console.log(err));
        ticketdb3.set(
        `BOTMAKERORDERNUMBER_${interaction.guild.id}`,
        parseInt(ticketnumber + 1)
        );
         channel.send({
        content: `<@${interaction.user.id}>`,
        embeds: [welcomeMSG],
        components: [OrderButtons],
        });
        } catch (error) {
          console.log(error)
        }
      }else if(Selected === `Scammers_Selected`){
        const Type = `Scammer-checker`
        try {
          const scammerstatus = db6.get(`Scammer`) || "1";
          if (scammerstatus === "0") {//تعديل
            return await interaction.editReply({content:`***لا تستطيع شراء هذا البوت في الوقت الحالي***
            **تستطيع ان تحاول مره ثانيه عندما يكون متوفر**`,ephemeral: true,
          });
          }
          if(!interaction.guild.me.permissions.has('ADMINISTRATOR')) return i.reply({
            content: `I dont have permissions`,
            ephemeral: true,
            })
        const user = interaction.user.id
        const ticketnumber =
        ticketdb3.get(`BOTMAKERORDERNUMBER_${interaction.guild.id}`) || 1;
        const data = BOTMAKETDB.get(`BotMakerTicket_${interaction.guild.id}`);
        
        const ticketcategory = data.Category;
        const category = interaction.guild.channels.cache.find(
        (c) => c.id === `${ticketcategory}` && c.type === "GUILD_CATEGORY"
        );
        const ScammerPrice = db3.get(`ScammerP_${interaction.guild.id}`) || db3.get('ScammerP') || 1;
        const welcomeMSG = new Discord.MessageEmbed()
        .setColor(interaction.guild.me.displayHexColor)
        .setTitle(`شراء بوت كشف نصابين`)
            .setImage('https://cdn.discordapp.com/attachments/1184549472911499324/1193274624633491538/Picsart_24-01-06_21-26-09-843.jpg?ex=65ac1e98&is=6599a998&hm=378de25a2a538f0162026735284cfc5c35d2e3a4924d9cecd3c90d06c880e233&')
            .setDescription( 
              `**## * سعر البوت: ${ScammerPrice} <:emoji_2:1191103694297636965>

## * اضغط على شراء لتأكيد عملية الشراء

## * لاتنسى تفعيل الثلاث خيارات للبوت الخاص بك 

**`
            );
        
        
        const OrderButtons = new MessageActionRow().addComponents([
        new MessageButton()
        .setCustomId(`BOTMAKER_Close`) //تعديل
        .setStyle(`DANGER`)
        .setLabel(`اغلاق`)
        .setEmoji('❌')
        .setDisabled(false),
        new MessageButton()
        .setCustomId(`Scammer_Continue`) //تعديل
        .setStyle(`SUCCESS`)
        .setLabel("شراء")
        .setEmoji('🛒')
        .setDisabled(false),
        ]);
        
        const channel = await interaction.guild.channels.create(`كشف نصابين-${ticketnumber}`, {
        type: "text",
        parent: category,
        permissionOverwrites: [
        {
        id: interaction.guild.roles.everyone.id,
        deny: ["VIEW_CHANNEL"],
        },
        {
        id: `${user}`,
        allow: ["VIEW_CHANNEL"],
        },
        ],
        topic: `${user}`,
        });
        await interaction.editReply({
        content: `تم فتح تكت شراء بوت : ${channel}`,
        ephemeral: true,
        })
        .catch((err) => console.log(err));
        ticketdb3.set(
        `BOTMAKERORDERNUMBER_${interaction.guild.id}`,
        parseInt(ticketnumber + 1)
        );
         channel.send({
        content: `<@${interaction.user.id}>`,
        embeds: [welcomeMSG],
        components: [OrderButtons],
        });
        } catch (error) {
          console.log(error)
        }
      }else if(Selected === `Giveaway_Selected`){
        const Type = `Giveaway`
        try {
          const giveawaystatus = db6.get(`Giveaway`) || "1";
          if (giveawaystatus === "0") {//تعديل
            return await interaction.editReply({content:`***لا تستطيع شراء هذا البوت في الوقت الحالي***
            **تستطيع ان تحاول مره ثانيه عندما يكون متوفر**`,ephemeral: true,
          });
          }
          if(!interaction.guild.me.permissions.has('ADMINISTRATOR')) return i.reply({
            content: `I dont have permissions`,
            ephemeral: true,
            })
        const user = interaction.user.id
        const ticketnumber =
        ticketdb3.get(`BOTMAKERORDERNUMBER_${interaction.guild.id}`) || 1;
        const data = BOTMAKETDB.get(`BotMakerTicket_${interaction.guild.id}`);
        
        const ticketcategory = data.Category;
        const category = interaction.guild.channels.cache.find(
        (c) => c.id === `${ticketcategory}` && c.type === "GUILD_CATEGORY"
        );
        const GiveawaysPrice = db3.get(`GiveawaysP_${interaction.guild.id}`) || db3.get('GiveawaysP') || 1;
        const welcomeMSG = new Discord.MessageEmbed()
        .setColor(interaction.guild.me.displayHexColor)
        .setTitle(`شراء بوت جيف واي`)
            .setImage('https://cdn.discordapp.com/attachments/1184549472911499324/1193274624977412106/Picsart_24-01-06_21-26-18-531.jpg?ex=65ac1e98&is=6599a998&hm=8b0066561a6af5434875dcf5a6a068f5e621340fd63837eb8abac402f4d59fdd&')
            .setDescription( 
              `**## * سعر البوت: ${GiveawaysPrice} <:emoji_2:1191103694297636965>

## * اضغط على شراء لتأكيد عملية الشراء

## * لاتنسى تفعيل الثلاث خيارات للبوت الخاص بك 

**`
            );
        
        const OrderButtons = new MessageActionRow().addComponents([
        new MessageButton()
        .setCustomId(`BOTMAKER_Close`) //تعديل
        .setStyle(`DANGER`)
        .setLabel(`اغلاق`)
        .setEmoji('❌')
        .setDisabled(false),
        new MessageButton()
        .setCustomId(`Giveaways_Continue`) //تعديل
        .setStyle(`SUCCESS`)
        .setLabel("شراء")
        .setEmoji('🛒')
        .setDisabled(false),
        ]);
        
        const channel = await interaction.guild.channels.create(`جيف واي-${ticketnumber}`, {
        type: "text",
        parent: category,
        permissionOverwrites: [
        {
        id: interaction.guild.roles.everyone.id,
        deny: ["VIEW_CHANNEL"],
        },
        {
        id: `${user}`,
        allow: ["VIEW_CHANNEL"],
        },
        ],
        topic: `${user}`,
        });
        await interaction.editReply({
        content: `تم فتح تكت شراء بوت : ${channel}`,
        ephemeral: true,
        })
        .catch((err) => console.log(err));
        ticketdb3.set(
        `BOTMAKERORDERNUMBER_${interaction.guild.id}`,
        parseInt(ticketnumber + 1)
        );
         channel.send({
        content: `<@${interaction.user.id}>`,
        embeds: [welcomeMSG],
        components: [OrderButtons],
        });
        } catch (error) {
          console.log(error)
        }
      }else if(Selected === `Probot_selected`){
        const Type = `Probot-Fake`
        try {
          const probotstatus = db6.get(`Probot`) || "1";
          if (probotstatus === "0") {//تعديل
            return await interaction.editReply({content:`***لا تستطيع شراء هذا البوت في الوقت الحالي***
            **تستطيع ان تحاول مره ثانيه عندما يكون متوفر**`,ephemeral: true,
          });
          }
          if(!interaction.guild.me.permissions.has('ADMINISTRATOR')) return i.reply({
            content: `I dont have permissions`,
            ephemeral: true,
            })
        const user = interaction.user.id
        const ticketnumber =
        ticketdb3.get(`BOTMAKERORDERNUMBER_${interaction.guild.id}`) || 1;
        const data = BOTMAKETDB.get(`BotMakerTicket_${interaction.guild.id}`);
        
        const ticketcategory = data.Category;
        const category = interaction.guild.channels.cache.find(
        (c) => c.id === `${ticketcategory}` && c.type === "GUILD_CATEGORY"
        );
        const ProbotPrice = db3.get(`ProbotP_${interaction.guild.id}`) || db3.get('ProbotP') || 1;
        const welcomeMSG = new Discord.MessageEmbed()
        .setColor(interaction.guild.me.displayHexColor)
        .setTitle(`شراء بوت بروبوت`)
            .setImage('https://cdn.discordapp.com/attachments/1184549472911499324/1193274625275203614/Picsart_24-01-06_21-26-27-243.jpg?ex=65ac1e98&is=6599a998&hm=b2185574be3043d34a387142a18419cb7debf326eb094b1dbaf2e2d7014ec358&')
            .setDescription( 
              `**## * سعر البوت: ${ProbotPrice} <:emoji_2:1191103694297636965>

## * اضغط على شراء لتأكيد عملية الشراء

## * لاتنسى تفعيل الثلاث خيارات للبوت الخاص بك 

**`
            );
        
        const OrderButtons = new MessageActionRow().addComponents([
        new MessageButton()
        .setCustomId(`BOTMAKER_Close`) //تعديل
        .setStyle(`DANGER`)
        .setLabel(`اغلاق`)
        .setEmoji('❌')
        .setDisabled(false),
        new MessageButton()
        .setCustomId(`Probot_Continue`) //تعديل
        .setStyle(`SUCCESS`)
        .setLabel("شراء")
        .setEmoji('🛒')
        .setDisabled(false),
        ]);
        
        const channel = await interaction.guild.channels.create(`بروبوت-${ticketnumber}`, {
        type: "text",
        parent: category,
        permissionOverwrites: [
        {
        id: interaction.guild.roles.everyone.id,
        deny: ["VIEW_CHANNEL"],
        },
        {
        id: `${user}`,
        allow: ["VIEW_CHANNEL"],
        },
        ],
        topic: `${user}`,
        });
        await interaction.editReply({
        content: `تم فتح تكت شراء بوت : ${channel}`,
        ephemeral: true,
        })
        .catch((err) => console.log(err));

        ticketdb3.set(
        `BOTMAKERORDERNUMBER_${interaction.guild.id}`,
        parseInt(ticketnumber + 1)
        );
         channel.send({
        content: `<@${interaction.user.id}>`,
        embeds: [welcomeMSG],
        components: [OrderButtons],
        });
        } catch (error) {
          console.log(error)
        }
      }else if(Selected === `Feedback_selected`){
        const Type = `FeedBack`
        try {
          const feedbackstatus = db6.get(`Feed`) || "1";
          if (feedbackstatus === "0") {//تعديل
            return await interaction.editReply({content:`***لا تستطيع شراء هذا البوت في الوقت الحالي***
            **تستطيع ان تحاول مره ثانيه عندما يكون متوفر**`,ephemeral: true,
          });
          }
          if(!interaction.guild.me.permissions.has('ADMINISTRATOR')) return i.reply({
            content: `I dont have permissions`,
            ephemeral: true,
            })
        const user = interaction.user.id
        const ticketnumber =
        ticketdb3.get(`BOTMAKERORDERNUMBER_${interaction.guild.id}`) || 1;
        const data = BOTMAKETDB.get(`BotMakerTicket_${interaction.guild.id}`);
        
        const ticketcategory = data.Category;
        const category = interaction.guild.channels.cache.find(
        (c) => c.id === `${ticketcategory}` && c.type === "GUILD_CATEGORY"
        );
        const FeedbackPrice = db3.get(`FeedbackP_${interaction.guild.id}`) || db3.get('FeedbackP') || 1;
        const welcomeMSG = new Discord.MessageEmbed()
        .setColor(interaction.guild.me.displayHexColor)
        .setTitle(`شراء بوت آراء`)
            .setImage('https://cdn.discordapp.com/attachments/1184549472911499324/1193274623152902144/Picsart_24-01-06_21-26-34-846.jpg?ex=65ac1e98&is=6599a998&hm=aac54cb01b140b85361e980dbc885614c29c9b9edd35b88cc0c1ea8add5fcb59&')
            .setDescription( 
              `**## * سعر البوت: ${FeedbackPrice} <:emoji_2:1191103694297636965>

## * اضغط على شراء لتأكيد عملية الشراء

## * لاتنسى تفعيل الثلاث خيارات للبوت الخاص بك 

**`
            );
        
        const OrderButtons = new MessageActionRow().addComponents([
        new MessageButton()
        .setCustomId(`BOTMAKER_Close`) //تعديل
        .setStyle(`DANGER`)
        .setLabel(`اغلاق`)
        .setEmoji('❌')
        .setDisabled(false),
        new MessageButton()
        .setCustomId(`Feedback_Continue`) //تعديل
        .setStyle(`SUCCESS`)
        .setLabel("شراء")
        .setEmoji('🛒')    
        .setDisabled(false),
        ]);
        
        const channel = await interaction.guild.channels.create(`آراء-${ticketnumber}`, {
        type: "text",
        parent: category,
        permissionOverwrites: [
        {
        id: interaction.guild.roles.everyone.id,
        deny: ["VIEW_CHANNEL"],
        },
        {
        id: `${user}`,
        allow: ["VIEW_CHANNEL"],
        },
        ],
        topic: `${user}`,
        });
        await interaction.editReply({
        content: `تم فتح تكت شراء بوت : ${channel}`,
        ephemeral: true,
        })
        .catch((err) => console.log(err));
        ticketdb3.set(
        `BOTMAKERORDERNUMBER_${interaction.guild.id}`,
        parseInt(ticketnumber + 1)
        );
         channel.send({
        content: `<@${interaction.user.id}>`,
        embeds: [welcomeMSG],
        components: [OrderButtons],
        });
        } catch (error) {
          console.log(error)
        }
      }else if(Selected === `Logs_selected`){
        const Type = `logs`
        try {
          const logstatus = db6.get(`Log`) || "1";
          if (logstatus === "0") {//تعديل
            return await interaction.editReply({content:`***لا تستطيع شراء هذا البوت في الوقت الحالي***
            **تستطيع ان تحاول مره ثانيه عندما يكون متوفر**`,ephemeral: true,
          });
          }
          if(!interaction.guild.me.permissions.has('ADMINISTRATOR')) return i.reply({
            content: `I dont have permissions`,
            ephemeral: true,
            })
        const user = interaction.user.id
        const ticketnumber =
        ticketdb3.get(`BOTMAKERORDERNUMBER_${interaction.guild.id}`) || 1;
        const data = BOTMAKETDB.get(`BotMakerTicket_${interaction.guild.id}`);
        
        const ticketcategory = data.Category;
        const category = interaction.guild.channels.cache.find(
        (c) => c.id === `${ticketcategory}` && c.type === "GUILD_CATEGORY"
        );
        const LogPrice = db3.get(`LogP_${interaction.guild.id}`) || db3.get('LogP') || 1;
        const welcomeMSG = new Discord.MessageEmbed()
        .setColor(interaction.guild.me.displayHexColor)
        .setTitle(`شراء بوت لوج`)
            .setImage('https://cdn.discordapp.com/attachments/1184549472911499324/1193274623589097493/Picsart_24-01-06_21-26-42-235.jpg?ex=65ac1e98&is=6599a998&hm=11f91e79dc7e40f095e8c5d4505a5e0aff32642aaf04f1e1278d81e2e52c7721&')
            .setDescription( 
              `**## * سعر البوت: ${LogPrice} <:emoji_2:1191103694297636965>

## * اضغط على شراء لتأكيد عملية الشراء

## * لاتنسى تفعيل الثلاث خيارات للبوت الخاص بك 

**`
            );
        
        const OrderButtons = new MessageActionRow().addComponents([
        new MessageButton()
        .setCustomId(`BOTMAKER_Close`) //تعديل
        .setStyle(`DANGER`)
        .setLabel(`اغلاق`)
        .setEmoji('❌')
        .setDisabled(false),
        new MessageButton()
        .setCustomId(`Log_Continue`) //تعديل
        .setStyle(`SUCCESS`)
        .setLabel("شراء")
        .setEmoji('🛒')
        .setDisabled(false),
        ]);
        
        const channel = await interaction.guild.channels.create(`لوج-${ticketnumber}`, {
        type: "text",
        parent: category,
        permissionOverwrites: [
        {
        id: interaction.guild.roles.everyone.id,
        deny: ["VIEW_CHANNEL"],
        },
        {
        id: `${user}`,
        allow: ["VIEW_CHANNEL"],
        },
        ],
        topic: `${user}`,
        });
        await interaction.editReply({
        content: `تم فتح تكت شراء بوت : ${channel}`,
        ephemeral: true,
        })
        .catch((err) => console.log(err));
        ticketdb3.set(
        `BOTMAKERORDERNUMBER_${interaction.guild.id}`,
        parseInt(ticketnumber + 1)
        );
         channel.send({
        content: `<@${interaction.user.id}>`,
        embeds: [welcomeMSG],
        components: [OrderButtons],
        });
        } catch (error) {
          console.log(error)
        }
      }else if(Selected === `Shop_selected`){
        const Type = `Shop`
        try {
          const shopstatus = db6.get(`Shop`) || "1";
          if (shopstatus === "0") {//تعديل
            return await interaction.editReply({content:`***لا تستطيع شراء هذا البوت في الوقت الحالي***
            **تستطيع ان تحاول مره ثانيه عندما يكون متوفر**`,ephemeral: true,
          });
          }
          if(!interaction.guild.me.permissions.has('ADMINISTRATOR')) return i.reply({
            content: `I dont have permissions`,
            ephemeral: true,
            })
        const user = interaction.user.id
        const ticketnumber =
        ticketdb3.get(`BOTMAKERORDERNUMBER_${interaction.guild.id}`) || 1;
        const data = BOTMAKETDB.get(`BotMakerTicket_${interaction.guild.id}`);
        
        const ticketcategory = data.Category;
        const category = interaction.guild.channels.cache.find(
        (c) => c.id === `${ticketcategory}` && c.type === "GUILD_CATEGORY"
        );
        const ShopPrice = db3.get(`ShopP_${interaction.guild.id}`) || db3.get('ShopP') || 1;
        const welcomeMSG = new Discord.MessageEmbed()
        .setColor(interaction.guild.me.displayHexColor)
        .setTitle(`شراء بوت شوب`)
            .setImage('https://cdn.discordapp.com/attachments/1184549472911499324/1193274624193073242/Picsart_24-01-06_21-26-48-387.jpg?ex=65ac1e98&is=6599a998&hm=72aa76a45012da5d4bf07b716e443e5f6b26ee206ff94824fd1322f97ca5f5f3&')
            .setDescription( 
              `**## * سعر البوت: ${ShopPrice} <:emoji_2:1191103694297636965>

## * اضغط على شراء لتأكيد عملية الشراء

## * لاتنسى تفعيل الثلاث خيارات للبوت الخاص بك 

**`
            );
        
        const OrderButtons = new MessageActionRow().addComponents([
        new MessageButton()
        .setCustomId(`BOTMAKER_Close`) //تعديل
        .setStyle(`DANGER`)
        .setLabel(`اغلاق`)
        .setEmoji('❌')
        .setDisabled(false),
        new MessageButton()
        .setCustomId(`Shop_Continue`) //تعديل
        .setStyle(`SUCCESS`)
        .setLabel("شراء")
        .setEmoji('🛒')
        .setDisabled(false),
        ]);
        
        const channel = await interaction.guild.channels.create(`شوب-${ticketnumber}`, {
        type: "text",
        parent: category,
        permissionOverwrites: [
        {
        id: interaction.guild.roles.everyone.id,
        deny: ["VIEW_CHANNEL"],
        },
        {
        id: `${user}`,
        allow: ["VIEW_CHANNEL"],
        },
        ],
        topic: `${user}`,
        });
        await interaction.editReply({
        content: `تم فتح تكت شراء بوت : ${channel}`,
        ephemeral: true,
        })
        .catch((err) => console.log(err));
        ticketdb3.set(
        `BOTMAKERORDERNUMBER_${interaction.guild.id}`,
        parseInt(ticketnumber + 1)
        );
         channel.send({
        content: `<@${interaction.user.id}>`,
        embeds: [welcomeMSG],
        components: [OrderButtons],
        });
        } catch (error) {
          console.log(error)
        }
      }else if(Selected === `BOTMAKER_Tier1_Selected`){//تعديل
        try {
          
          const Type = `BOTMAKER-Tier-1`
          const botmakerstatus = db6.get(`BotMaker`) || "1";//تعديل
          if (botmakerstatus === "0") {//تعديل
            return await interaction.editReply({content:`***لا تستطيع شراء هذا البوت في الوقت الحالي***
            **تستطيع ان تحاول مره ثانيه عندما يكون متوفر**`,ephemeral: true,
          });
          }
        const user = interaction.user.id
        const ticketnumber =
        ticketdb3.get(`BOTMAKERORDERNUMBER_${interaction.guild.id}`) || 1;
        const data = BOTMAKETDB.get(`BotMakerTicket_${interaction.guild.id}`);
        
        const ticketcategory = data.Category;
        const category = interaction.guild.channels.cache.find(
        (c) => c.id === `${ticketcategory}` && c.type === "GUILD_CATEGORY"
        );
        
        const welcomeMSG = new Discord.MessageEmbed()
        .setColor(interaction.guild.me.displayHexColor)
        .setDescription(
        `**لاستكمال عمليه الشراء قم بضغط علي زر**\n**"Continue"**\n**BotType :** __${Type}__`
        );
        
        const OrderButtons = new MessageActionRow().addComponents([
        new MessageButton()
        .setCustomId(`BOTMAKER_Close`) //تعديل
        .setStyle(`DANGER`)
        .setLabel(`Close`)
        .setDisabled(false),
        new MessageButton()
        .setCustomId(`BOTMAKER_Tier1_Continue`) //تعديل
        .setStyle(`SUCCESS`)
        .setLabel("Continue")
        .setDisabled(false),
        ]);
        
        const channel = await interaction.guild.channels.create(`ticket-${ticketnumber}`, {
        type: "text",
        parent: category,
        permissionOverwrites: [
        {
        id: interaction.guild.roles.everyone.id,
        deny: ["VIEW_CHANNEL"],
        },
        {
        id: `${user}`,
        allow: ["VIEW_CHANNEL"],
        },
        ],
        topic: `${user}`,
        });
        await interaction.editReply({
        content: `Your ticket has been created: ${channel}`,
        ephemeral: true,
        })
        .catch((err) => console.log(err));
        ticketdb3.set(
        `BOTMAKERORDERNUMBER_${interaction.guild.id}`,
        parseInt(ticketnumber + 1)
        );
         channel.send({
        content: `<@${interaction.user.id}>`,
        embeds: [welcomeMSG],
        components: [OrderButtons],
        });
        } catch (error) {
          console.log(error)
        }
      }else if(Selected === `BOTMAKER_Tier2_Selected`){//تعديل
        try {
         
          const amount = db.get(`BotMaker_Amount_${client.user.id}_Tier_2`) || 0
          if(interaction.guild.id !== CoderServer && amount <=0){
            return await interaction.editReply({content:`[😞] لا يوجد كميه متوفره من هذا النوع`,ephemeral: true})
          }
          const Type = `BOTMAKER-Tier-2`
          const botmakerstatus = db6.get(`BotMaker`) || "1";//تعديل
          if (botmakerstatus === "0") {//تعديل
            return await interaction.editReply({content:`***لا تستطيع شراء هذا البوت في الوقت الحالي***
            **تستطيع ان تحاول مره ثانيه عندما يكون متوفر**`,ephemeral: true,
          });
          }
        const user = interaction.user.id
        const ticketnumber =
        ticketdb3.get(`BOTMAKERORDERNUMBER_${interaction.guild.id}`) || 1;
        const data = BOTMAKETDB.get(`BotMakerTicket_${interaction.guild.id}`);
        
        const ticketcategory = data.Category;
        const category = interaction.guild.channels.cache.find(
        (c) => c.id === `${ticketcategory}` && c.type === "GUILD_CATEGORY"
        );
        
        const welcomeMSG = new Discord.MessageEmbed()
        .setColor(interaction.guild.me.displayHexColor)
        .setDescription(
        `**لاستكمال عمليه الشراء قم بضغط علي زر**\n**"Continue"**\n**BotType :** __${Type}__`
        );
        
        const OrderButtons = new MessageActionRow().addComponents([
        new MessageButton()
        .setCustomId(`BOTMAKER_Close`) //تعديل
        .setStyle(`DANGER`)
        .setLabel(`Close`)
        .setDisabled(false),
        new MessageButton()
        .setCustomId(`BOTMAKER_Tier2_Continue`) //تعديل
        .setStyle(`SUCCESS`)
        .setLabel("Continue")
        .setDisabled(false),
        ]);
        
        const channel = await interaction.guild.channels.create(`ticket-${ticketnumber}`, {
        type: "text",
        parent: category,
        permissionOverwrites: [
        {
        id: interaction.guild.roles.everyone.id,
        deny: ["VIEW_CHANNEL"],
        },
        {
        id: `${user}`,
        allow: ["VIEW_CHANNEL"],
        },
        ],
        topic: `${user}`,
        });
        await interaction.editReply({
        content: `Your ticket has been created: ${channel}`,
        ephemeral: true,
        })
        .catch((err) => console.log(err));
        ticketdb3.set(
        `BOTMAKERORDERNUMBER_${interaction.guild.id}`,
        parseInt(ticketnumber + 1)
        );
         channel.send({
        content: `<@${interaction.user.id}>`,
        embeds: [welcomeMSG],
        components: [OrderButtons],
        });
        } catch (error) {
          console.log(error)
        }
      }else if(Selected === `BOTMAKER_Tier3_Selected`){//تعديل
        try {
          
          const amount = db.get(`BotMaker_Amount_${client.user.id}_Tier_3`) || 0
          if(interaction.guild.id !== CoderServer && amount <=0){
            return await interaction.editReply({content:`[😞] لا يوجد كميه متوفره من هذا النوع`,ephemeral: true})
          }
          const Type = `BOTMAKER-Tier-3`
          const botmakerstatus = db6.get(`BotMaker`) || "1";//تعديل
          if (botmakerstatus === "0") {//تعديل
            return await interaction.editReply({content:`***لا تستطيع شراء هذا البوت في الوقت الحالي***
            **تستطيع ان تحاول مره ثانيه عندما يكون متوفر**`,ephemeral: true,
          });
          }
        const user = interaction.user.id
        const ticketnumber =
        ticketdb3.get(`BOTMAKERORDERNUMBER_${interaction.guild.id}`) || 1;
        const data = BOTMAKETDB.get(`BotMakerTicket_${interaction.guild.id}`);
        
        const ticketcategory = data.Category;
        const category = interaction.guild.channels.cache.find(
        (c) => c.id === `${ticketcategory}` && c.type === "GUILD_CATEGORY"
        );
        
        const welcomeMSG = new Discord.MessageEmbed()
        .setColor(interaction.guild.me.displayHexColor)
        .setDescription(
        `**لاستكمال عمليه الشراء قم بضغط علي زر**\n**"Continue"**\n**BotType :** __${Type}__`
        );
        
        const OrderButtons = new MessageActionRow().addComponents([
        new MessageButton()
        .setCustomId(`BOTMAKER_Close`) //تعديل
        .setStyle(`DANGER`)
        .setLabel(`Close`)
        .setDisabled(false),
        new MessageButton()
        .setCustomId(`BOTMAKER_Tier3_Continue`) //تعديل
        .setStyle(`SUCCESS`)
        .setLabel("Continue")
        .setDisabled(false),
        ]);
        
        const channel = await interaction.guild.channels.create(`ticket-${ticketnumber}`, {
        type: "text",
        parent: category,
        permissionOverwrites: [
        {
        id: interaction.guild.roles.everyone.id,
        deny: ["VIEW_CHANNEL"],
        },
        {
        id: `${user}`,
        allow: ["VIEW_CHANNEL"],
        },
        ],
        topic: `${user}`,
        });
        await interaction.editReply({
        content: `Your ticket has been created: ${channel}`,
        ephemeral: true,
        })
        .catch((err) => console.log(err));
        ticketdb3.set(
        `BOTMAKERORDERNUMBER_${interaction.guild.id}`,
        parseInt(ticketnumber + 1)
        );
         channel.send({
        content: `<@${interaction.user.id}>`,
        embeds: [welcomeMSG],
        components: [OrderButtons],
        });
        } catch (error) {
          console.log(error)
        }
      }
    } catch (error) {
      
    }

  }
}