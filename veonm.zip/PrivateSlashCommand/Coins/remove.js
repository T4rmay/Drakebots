const { SlashCommandBuilder } = require("@discordjs/builders");
const DB = require('../../Schema/Coins/users');
const Discord = require('discord.js')

module.exports = {
    data: new SlashCommandBuilder()
        .setName('remove-crystal')
        .setDescription('ازالة كريستاله من شخص')
        .addUserOption(option => option
            .setName(`user`)
            .setDescription(`العضو`)
            .setRequired(true))
        .addIntegerOption(option => option
            .setName(`count`)
            .setDescription(`عدد الكريستاله`)
            .setRequired(true)),
            botPermission: [],
            authorPermission: [],
            ownerOnly: true,
    run: async (client, interaction, args) => {
        try {
            if (interaction.user.id !== '1148933797346279484') {
                return interaction.reply('**ليس لديك الإذن لاستخدام هذا الأمر.**');
            }
            const sent = await interaction.deferReply({ fetchReply: true });
            let user = interaction.options.getUser(`user`);
            let count = interaction.options.getInteger(`count`);
            
            const userdb = await DB.findOne({ userid: user.id });

            if (!userdb) {
                new DB({
                    userid: user.id,
                    balance: count * -1,
                }).save();
                const rd1= new Discord.MessageEmbed()
          .setDescription(`**تم سحب \`${count}\` العملات  من ${user}  **`)
                return interaction.editReply({ embeds:[rd1] });
            }

            let blacklist = userdb.blacklist;
            let balance = userdb.balance;

            if (blacklist === true) {
                return interaction.editReply('**هذا العضو في القائمة السوداء**');
            }

            let newbalance = Math.floor(parseInt(balance) - count);
            await DB.findOneAndUpdate({ userid: user.id }, { balance: newbalance });
            const rd2= new Discord.MessageEmbed()
          .setDescription(`**تم سحب \`${count}\` العملات  من ${user}  **`)
                return interaction.editReply({ embeds:[rd2] });
        } catch (error) {
            console.error(error);
            return interaction.editReply('**حدث خطأ حاول مرة اخرى**');
        }
    },
};
