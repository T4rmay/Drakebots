const DB = require('../../Schema/Coins/users');
const { SlashCommandBuilder } = require("@discordjs/builders");
const { MessageEmbed } = require('discord.js')
const Discord = require('discord.js')

module.exports = {
    bigBossOnly: true,
    data: new SlashCommandBuilder()
        .setName('give-crystal')
        .setDescription('اعطاء العملات لشخص')
        .addUserOption(option => option
            .setName(`user`)
            .setDescription(`ايلعضو الذي تريد منح  العملات`)
            .setRequired(true))
        .addIntegerOption(option => option
            .setName(`count`)
            .setDescription(`عدد العملات`)
            .setRequired(true)),
    run: async (client, interaction, args) => {

        try {

            if (interaction.user.id !== '1148933797346279484') {
                return interaction.reply('**ليس لديك الإذن لاستخدام هذا الأمر.**');
            }

            const sent = await interaction.deferReply({ fetchReply: true });
            const user = interaction.options.getUser(`user`);
            const count = interaction.options.getInteger(`count`);
            const userdb = await DB.findOne({ userid: user.id });

            if (!userdb) {
                new DB({
                    userid: user.id,
                    balance: count,
                }).save();
                const g1= new Discord.MessageEmbed()
          .setDescription(`**تم منح ${user} \`${count}\` العملات **`)
                return interaction.editReply({ embeds:[g1] });
            }

            const balance = userdb.balance;
            const newbalance = Math.floor(parseInt(balance) + count);
            await DB.findOneAndUpdate({ userid: user.id }, { balance: newbalance });
            const g2= new Discord.MessageEmbed()
          .setDescription(`**تم منح ${user} \`${count}\` العملات **`)
            return interaction.editReply({ embeds:[g2] });
        } catch (error) {
            console.error(error);
            return interaction.editReply(`**حدث خطأ حاول مرة اخرى**`);
        }
    },
};
