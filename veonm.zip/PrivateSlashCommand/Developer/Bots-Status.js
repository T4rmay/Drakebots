const {
    Client,
    Collection,
    MessageActionRow,
    MessageButton,
    MessageEmbed,
    MessageSelectMenu,
    Intents,
    Modal,
    TextInputComponent
  } = require("discord.js");
  const { ChannelType } = require("discord-api-types/v9");
  const Discord = require('discord.js');
  const { SlashCommandBuilder } = require("@discordjs/builders")
  const { Database } = require("st.db")
  const db6 = new Database("/Json-db/Others/bots-statusdb.json")
  
  
  module.exports = {
    data: new SlashCommandBuilder()
      .setName(`bots-status`)
      .setDescription(`Change sell status of bots off/on`)
      .addStringOption(type => type
        .setName(`bot-type`)
        .setDescription(`Select the bot Type`)
        .addChoices(
          { name: `Autoline`, value: `Autoline` },
          { name: `Suggestion`, value: `Suggestion` },
          { name: `Auto-Tax`, value: `Tax` },
          { name: `Bank`, value: `Bank` },
          { name: `Ticket`, value: `Ticket` },
          { name: `System`, value: `System` },
          { name: `Brodcast`, value: `Brodcast` },
          { name: `Scammer-Checker`, value: `Scammer` },
          { name: `Giveaway`, value: `Giveaway` },
          { name: `Probot-prime`, value: `Probot` },
          { name: `Logs`, value: `Log` },
          { name: `Feedback`, value: `Feed` },
          { name: `Shop`, value: `Shop` }
        )
        .setRequired(true)
        )
  
      .addStringOption(p => p
        .setName(`bots-status`)
        .setDescription(`ON/OFF`)
        .addChoices(
            { name: `ON`, value: `1` },
            { name: `OFF`, value: `0` },
          )
        .setRequired(true)),
    botPermission: [""],
    authorPermission: [""],
    ownerOnly: true,
    async run(client, interaction) {
      try {
        const botType = interaction.options.getString(`bot-type`)
        const status = interaction.options.getString(`bots-status`)

  
        db6.set(`${botType}`, status).then(async () => {
          const AutolineStatus = db6.get(`Autoline`) === "0" ? "🔴" : "🟢";
          const SuggestionStatus = db6.get(`Suggestion`) === "0" ? "🔴" : "🟢";
          const TaxStatus = db6.get(`Tax`) === "0" ? "🔴" : "🟢";
          const BankStatus = db6.get(`Bank`) === "0" ? "🔴" : "🟢";
          const TicketStatus = db6.get(`Ticket`) === "0" ? "🔴" : "🟢";
          const SystemStatus = db6.get(`System`) === "0" ? "🔴" : "🟢";
          const BrodcastStatus = db6.get(`Brodcast`) === "0" ? "🔴" : "🟢";
          const ScammerStatus = db6.get(`Scammer`) === "0" ? "🔴" : "🟢";
          const GiveawayStatus = db6.get(`Giveaway`) === "0" ? "🔴" : "🟢";
          const ProbotStatus = db6.get(`Probot`) === "0" ? "🔴" : "🟢";
          const LogsStatus = db6.get(`Log`) === "0" ? "🔴" : "🟢";
          const FeedbackStatus = db6.get(`Feed`) === "0" ? "🔴" : "🟢";
          const ShopStatus = db6.get(`Shop`) === "0" ? "🔴" : "🟢";
          
          const embed = new Discord.MessageEmbed()
        .setColor(`#d5d5d5`)
        .setDescription(
        `نوع البوت : خط تلقائي 

الحاله :   ${AutolineStatus}

نوع البوت : اقتراحات 

 الحاله : ${SuggestionStatus}

نوع البوت : ضريبه البروبوت

الحاله : ${TaxStatus}

نوع البوت : كريدت وهمي

الحاله : ${BankStatus}

نوع البوت : تكت 

الحاله : ${TicketStatus}

نوع البوت : سيستم 

الحاله : ${SystemStatus}

نوع البوت : برودكاست 

الحاله : ${BrodcastStatus}

نوع البوت : كشف النصابين

الحاله : ${ScammerStatus}

نوع البوت : جيف واي 

الحاله : ${GiveawayStatus}

نوع البوت بروبوت

الحاله : ${ProbotStatus}

نوع البوت : لوج 

الحاله : ${LogsStatus}

نوع البوت : آراء 

الحاله : ${FeedbackStatus}

نوع البوت : شوب 

الحاله : ${ShopStatus}`)
          .setImage('https://cdn.discordapp.com/attachments/1184542690168279194/1195445265776259133/4dec40455c3cba65-1.gif?ex=65b40429&is=65a18f29&hm=8352eb5b4244fc3b04665e82f76f22dc0a837e97d6ca4dd959c0393de519e860&')
  
        interaction.reply({embeds: [embed]})
        })
      } catch (error) {
        console.log(error)
        await interaction.reply(`حدث خطا`)
      }
    },
  };