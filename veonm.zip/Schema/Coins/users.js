const mongodb = require('mongoose');
const { CLIENTID , mainGuild } = require("../../index")
const schema = new mongodb.Schema({
   
    userid:{
        type:String
    },
    balance:{
        type:String,
        default:0
    }
    
});
module.exports = mongodb.model('user' , schema)