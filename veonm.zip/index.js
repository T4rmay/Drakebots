const { Client, MessageEmbed, Collection } = require("discord.js");
const Discord = require("discord.js");
const client = new Client({ intents: 32767 });
const DiscordModals = require(`discord-modals`);
DiscordModals(client);
const { token, prefix, CLIENTID, mainGuild, mongoDB, join_leavelog } = require("./config.json");
const { Database } = require("st.db");
const db = new Database("database.json");
const chalk = require("chalk");
client.login(token).catch((err) => console.log("❌ Token are not working"));
const { readdirSync } = require("fs");
const { REST } = require("@discordjs/rest");
const { Routes } = require("discord-api-types/v9");
const os = require('os-utils');
const { mongoose } = require("mongoose")
const fs = require('fs');
const path = require('path');
const moment = require('moment-timezone');
moment.tz.setDefault('Africa/Cairo');
const DB = require('./Schema/Coins/users');



const BOTMAKERSUBSDB = new Database("/Json-db/BotMaker/BotMakerSub.json")







client.on("ready", async () => {
  mongoose.connect(mongoDB, { useNewUrlParser: true, useUnifiedTopology: true })
    .then(() => {
      console.log(chalk.green("Connected to DB"));
    })
    .catch((error) => {
      console.error('Error connecting to MongoDB', error);
    });
});

module.exports = client;
exports.mainBot = client;
client.on("ready", async () => {
  const rest = new REST({ version: "9" }).setToken(token);
  (async () => {
    try {
      await rest.put(Routes.applicationCommands(CLIENTID), {
        body: slashcommands,
      });

      console.log("/ Commands are loaded");
    } catch (error) {
      console.error(error);
    }
    try {
      await rest.put(Routes.applicationGuildCommands(CLIENTID, mainGuild), {
        body: Guildcommands,
      });

      console.log("/guild Commands are loaded");
    } catch (error) {
      console.error(error);
    }
  })();
});



client.slashcommands = new Collection();
const slashcommands = [];

const ascii = require("ascii-table");
const table = new ascii("P-Commands").setJustify();
for (let folder of readdirSync("./PuplicSlashCommand/").filter(
  (folder) => !folder.includes(".")
)) {
  for (let file of readdirSync("./PuplicSlashCommand/" + folder).filter((f) =>
    f.endsWith(".js")
  )) {
    let command = require(`./PuplicSlashCommand/${folder}/${file}`);
    if (command) {
      slashcommands.push(command.data);
      client.slashcommands.set(command.data.name, command);
      if (command.data.name) {
        table.addRow(`/${command.data.name}`, "🟢 Working");
      } else {
        table.addRow(`/${command.data.name}`, "🔴 Not Working");
      }
    }
  }
}
console.log(table.toString());

client.Guildcommands = new Collection();
const Guildcommands = [];
const Guildtable = new ascii("G-Commands").setJustify();
for (let folder of readdirSync("./PrivateSlashCommand/").filter(
  (folder) => !folder.includes(".")
)) {
  for (let file of readdirSync("./PrivateSlashCommand/" + folder).filter((f) =>
    f.endsWith(".js")
  )) {
    let command = require(`./PrivateSlashCommand/${folder}/${file}`);
    if (command) {
      Guildcommands.push(command.data);
      client.Guildcommands.set(command.data.name, command);
      if (command.data.name) {
        Guildtable.addRow(`/${command.data.name}`, "🟢 Working");
      } else {
        Guildtable.addRow(`/${command.data.name}`, "🔴 Not Working");
      }
    }
  }
}
console.log(Guildtable.toString());

const process = require("process");



client.on('ready', () => {
  console.log(chalk.magentaBright('The bot is ready'));
  console.log(chalk.red('Bot Name: ') + chalk.blue(client.user.tag));

      const ramUsage = os.freememPercentage() * 100;


      const botstatus = db.get('Status');
      client.user.setActivity('Verison 1.0', {
        type: 'PLAYING',
        url: 'https://www.twitch.tv/venom2',
      });
      client.user.setPresence({
        status: botstatus,
      });
});









client.commands = new Discord.Collection();
client.events = new Discord.Collection();
client.buttons = new Discord.Collection();
client.selectMenus = new Discord.Collection();
client.modlas = new Discord.Collection();
require("./handlers/commands")(client);
require("./handlers/events")(client);
require("./handlers/Button")(client);
require("./handlers/selectMenus")(client);
require("./handlers/Modal")(client);


client.on('err', (error) => {
  console.error('The bot encountered an error:', error);
});

process.on('unhandledRejection', (error) => {
  console.log(error)
});

process.on('uncaughtException', (err, origin) => {
  console.error(err)
});
process.on('uncaughtExceptionMonitor', (err, origin) => {
  console.error(err)

});
process.on('warning', (warning) => {
  
});

client.on('error', (error) => {
  console.error('An error occurred:', error);
});

client.on('shardError', (error) => {
  console.error('A shard error occurred:', error);
});


// client.on('err', (error) => {
  
// });

// process.on('unhandledRejection', (error) => {
  
// });

// process.on('uncaughtException', (err, origin) => {
  
// });
// process.on('uncaughtExceptionMonitor', (err, origin) => {
  
// });
// process.on('warning', (warning) => {
  
// });

// client.on('error', (error) => {
  
// });

// client.on('shardError', (error) => {
  
// });

// =================VC Joiner=================
 const { joinVoiceChannel } = require("@discordjs/voice");
 client.on("ready", () => {
   setInterval(async () => {
     const data = await db.get("24/7voice");
     if (!data) return;
     client.channels
       .fetch(data)
       .then((channel) => {
        const VoiceConnection = joinVoiceChannel({
          channelId: channel.id,
           guildId: channel.guild.id,
            adapterCreator: channel.guild.voiceAdapterCreator,
          });
        })
        .catch((error) => {
          return;
        });
    }, 1000);
  });
// =================VC Joiner=================

// =================Dev=================
//Whitelist System
client.on("guildCreate", async (guild) => {
  const subs = BOTMAKERSUBSDB.get(`AllowedServers_${client.user.id}`);
  if (!subs.includes(guild.id) &&
    guild.id !== "ايدي السيرفر الي يدخل فيه البوت") {
    guild.leave().catch(err => { })
  }
});

//guildCreate
client.on("guildCreate", async (guild) => {
  const { CoderServer, selllogsch, join_leavelog, owner } = require('./config.json');
  const targetGuildId = CoderServer;
  const targetChannelId = join_leavelog;
  const targetGuild = client.guilds.cache.get(targetGuildId);
  const Serverowner = await client.users.fetch(guild.ownerId);
  const ownerUsername = Serverowner ? Serverowner.username : "Unknown";
  const targetChannel = targetGuild.channels.cache.get(targetChannelId);

  const joinsEmbed = new Discord.MessageEmbed()
    .setTitle("Bot Maker Tier 1")
    .setColor("GREEN")
    .setDescription(`Joined: ${guild.name}\nOwner Mention: <@!${guild.ownerId}>\nOwner user: ${ownerUsername}`);

  targetChannel.send({ embeds: [joinsEmbed] });
});

//guildDelete
client.on("guildDelete", async (guild) => {
  const { CoderServer, selllogsch, join_leavelog, owner } = require('./config.json');
  const targetGuildId = CoderServer;
  const targetChannelId = join_leavelog;
  const targetGuild = client.guilds.cache.get(targetGuildId);
  const Serverowner = await client.users.fetch(guild.ownerId);
  const ownerUsername = Serverowner ? Serverowner.username : "Unknown";
  const targetChannel = targetGuild.channels.cache.get(targetChannelId);

  const leavesEmbed = new Discord.MessageEmbed()
    .setTitle("Bot Maker Tier 1")
    .setColor("RED")
    .setDescription(`Left: ${guild.name}\nOwner Mention: <@!${guild.ownerId}>\nOwner user: ${ownerUsername}`);

  targetChannel.send({ embeds: [leavesEmbed] });
});

client.on('ready', () => {
  const subs = BOTMAKERSUBSDB.get(`AllowedServers_${client.user.id}`) || []
  client.guilds.cache.forEach((guild) => {
    if (!subs.includes(guild.id) && guild.id !== 'ايدي السيرفر الاساسي') {
      if (guild) {
        guild.leave().catch(err => { })
      }
    }
  });
});


// =================require Dev=================

// =================Bots requires=================
const db6 = new Database("/Json-db/Others/bots-statusdb.json");
const ondb =  new Database("/Json-db/Others/ONStatus");

client.on('ready', () => {
  ondb.deleteAll()
});
  setInterval(async () => {
    const autolinestatus = db6.get(`Autoline`) || "1"
    const sta = ondb.get("AutolineS") || "off"
    if (autolinestatus === "0" && sta !== "on") {

    } else {
      require(`./Bots/Auto-line/Autoline-Bots`)
      await ondb.set(`AutolineS`,"on")
    }
  }, 7000);
  setInterval(async () => {
    const suggestionstatus = db6.get(`Suggestion`) || "1"
    const sta = ondb.get("SuggestionS") || "off"
    if (suggestionstatus === "0" && sta !== "on") {

    } else {
      require(`./Bots/Suggestion/Suggestion-Bots`)
      await ondb.set(`SuggestionS`,"on");
    }
  }, 25000);
  setInterval(async () => {
    const taxstatus = db6.get(`Tax`) || "1"
    const sta = ondb.get("TaxS") || "off"
    if (taxstatus === "0" && sta !== "on") {

    } else {
      require(`./Bots/Tax/Tax-Bots`)
      await ondb.set(`TaxS`,"on");
    }
  }, 40000);
  setInterval(async () => {
    const credittatus = db6.get(`Credit`) || "1"
    const sta = ondb.get("CreditS") || "off"
    if (credittatus === "0" && sta !== "on") {

    } else {
      require(`./Bots/Credit/Credit-bots`)
      await ondb.set(`CreditS`,"on");
    }
  }, 65000);
  setInterval(async () => {
    const ticketstatus = db6.get(`Ticket`) || "1"
    const sta = ondb.get("TicketS") || "off"
    if (ticketstatus === "0" && sta !== "on") {
    } else {
      require(`./Bots/Ticket/Ticket-Bots`)
      await ondb.set(`TicketS`,"on");
    }
  }, 80000);
  setInterval(async () => {
    const systemstatus = db6.get(`System`) || "1"
    const sta = ondb.get("SystemS") || "off"
    if (systemstatus === "0" && sta !== "on") {
    } else {
      require(`./Bots/System/System-bots`)
      await ondb.set(`SystemS`,"on");
    }
  }, 100000);
  setInterval(async () => {
    const brodcaststatus = db6.get(`Brodcast`) || "1"
    const sta = ondb.get("BrodcastS") || "off"
    if (brodcaststatus === "0" && sta !== "on") {
    } else {
      require(`./Bots/Brodcast/Brodcast-Bots`)
      await ondb.set(`BrodcastS`,"on");
    }
  }, 120000);
  setInterval(async () => {
    const scammerstatus = db6.get(`Scammer`) || "1"
    const sta = ondb.get("ScammerS") || "off"
    if (scammerstatus === "0" && sta !== "on") {
    } else {
      require(`./Bots/Scammer/Scammer-Bots`)
      await ondb.set(`ScammerS`,"on");
    }
  }, 135000);
  setInterval(async () => {
    const probotstatus = db6.get(`Probot`) || "1"
    const sta = ondb.get("ProbotS") || "off"
    if (probotstatus === "0" && sta !== "on") {
    } else {
      require(`./Bots/ProBot/Probot-Bots`)
      await ondb.set(`ProBotS`,"on");
    }
  }, 145000);
  setInterval(async () => {
    const feedstatus = db6.get(`Feed`) || "1"
    const sta = ondb.get("FeedbackS") || "off"
    if (feedstatus === "0" && sta !== "on") {
    } else {
      require(`./Bots/Feedback/Feedback-Bots`)
      await ondb.set(`FeedbackS`,"on")
    }
  }, 160000);
  setInterval(async () => {
    const shopstatus = db6.get(`Shop`) || "1"
    const sta = ondb.get("ShopS") || "off"
    if (shopstatus === "0" && sta !== "on") {
    } else {
      require(`./Bots/Shop/Shop-Bots`)
      await ondb.set(`ShopS`,"on")
    }
  }, 175000);
  setInterval(async () => {
    const logstatus = db6.get(`Log`) || "1"
    const sta = ondb.get("LogS") || "off"
    if (logstatus === "0" && sta !== "on") {
    } else {
      require(`./Bots/Log/Log-Bots`)
      await ondb.set(`LogS`,"on")
    }
  }, 195000);
  setInterval(async () => {
    const giveawaystatus = db6.get(`Giveaway`) || "1"
    const sta = ondb.get("GiveawayS") || "off"
    if (giveawaystatus === "0" && sta !== "on") {
    } else {
      require(`./Bots/Giveaways/Giveaways-Bots`)
      await ondb.set(`GiveawayS`,"on")
    }
  }, 215000);








// =================Bots requires=================
client.on(`ready`, () => {
  const db11 = new Database("/Json-db/Others/BuyerChecker.json");
  db11.deleteAll();
});

require(`./BotMaker2Bots`)
require(`./BotMaker3Bots`)


//require intercationCreate
// const folderPath = path.join(__dirname, 'intercationCreate');
// fs.readdirSync(folderPath).forEach(folder => {
//   const folderFullPath = path.join(folderPath, folder);
//   if (fs.lstatSync(folderFullPath).isDirectory()) {
//     fs.readdirSync(folderFullPath).forEach(file => {
//       if (file.endsWith('.js')) {
//         const filePath = path.join(folderFullPath, file);
//         require(filePath);
//       }
//     });
//   }
// });

//اشتراكات بوت ميكر تاير 1
const BOTMKERSUBSDB = new Database("/Json-db/BotMaker/BotMakerSubTime.json");
const BOTMAKETDB = new Database("/Json-db/BotMaker/BotMakerSub.json");
client.on('ready', () => {
  try {
    setInterval(() => {
      const currentTime = moment().format('YYYY-MM-DD HH:mm:ss');
      const subscriptions = BOTMKERSUBSDB.get(`TIMELEFTSUB`);
      if (subscriptions) {
        subscriptions.forEach(async subscription => {
          const { serverId, endTime, owner, Whitelist, Type } = subscription;
          if (moment(currentTime).isAfter(endTime)) {
            const whitelistedGuild = await client.guilds.fetch(serverId).catch(err => { })
            const guild = client.guilds.cache.get(mainGuild)
            const channel = guild.channels.cache.get(join_leavelog)
            if (guild && channel) {
              channel.send(``)
            }


            const check = BOTMKERSUBSDB.get(`TIMELEFTSUB`);
            const RemoveServer = check.filter(re => re.Whitelist !== Whitelist && re.Type !== Type);
            BOTMAKETDB.pull(`AllowedServers_${client.user.id}`, serverId).then(() => {
              BOTMKERSUBSDB.set(`TIMELEFTSUB`, RemoveServer).then(() => {
                if (whitelistedGuild) {
                  whitelistedGuild.leave();
                } else {
                }
              })
            })
          } else {

          }
        });
      }
    }, 1000);
  } catch (error) {
  }
});


client.on('ready', async () => {
  const data = await BOTMAKERSUBSDB.get(`AllowedServers_${client.user.id}`) || []

  client.guilds.cache.forEach((guild) => {
    if (!data.includes(guild.id) && guild.id !== `1179878986952740884`) {
      guild.leave().catch(err => { })
      console.log(`left ${guild.id}`)
    }
  });
});

client.on('message', message => {
  if (message.channel.id != "ايدي الروم الي لما يتبعت فيها الاوفر يروحل للروم الثانيه") return;
  const channel = client.channels.cache.find(channel => channel.id === "ايدي الروم الي يصل لها الطلبات");
  if (message.author.bot) return;
  var args = message.content.split(` `).slice(" ").join(" ")
  channel.send(`
  **${args}**
  
  : <@&ايدي الرول الي تتمنشن>
   البائع <@${message.author.id}>
   للطلب : <#ايدي روم الطلب> ومنشن البائع مرا واحده فقط`);
     return message.reply("Done sent the Offer")
})



client.on('messageCreate', message => {

const channelid = ["id1", "id2"]//ايدي روم الضريبه التلقائي

if(channelid.includes(message.channel.id) && !message.author.bot){

  const args = message.content.split(" ").join( )

  const args2 = args.replace("k", "000").replace("K", "000").replace("m", "000000").replace("M", "000000").replace("b", "000000000000").replace("B", "000000000000")

  const tax  = Math.floor(args2 * (20) / (19) + (1))

  const tax2  = Math.floor(args2 * (20) / (19) +(1) - (args2))

  const tax3  = Math.floor(tax2 * (20) / (20))

  if(!args.endsWith("k") && !args.endsWith("K") && !args.endsWith("m") && !args.endsWith("M") && !args.endsWith("b") && !args.endsWith("B") && isNaN(args)) return message.delete()

message.reply(`**
>  المبلغ دون ضريبه : ${args2}

>  الضريبه هيا :  ${tax3}

>  المبالغ ب الضريبه : ${tax}

**`)

}

})






client.on('messageCreate', async (message) => {

  if (message.channel.id === '') { // ايدي روم الاقتراحات

     if (message.author.bot) return;

    const content = message.content;

    await message.delete();

    const ThailandCodes = new MessageEmbed()

      .setColor('#000000')

      .setDescription(content)

      .setAuthor(message.member.user.tag)

      .addField('-', `Thanks for your suggestion, ${message.member.user}!`)

    

.setImage(``)////رابط الخط

      .setTimestamp();

    const vero = await message.channel.send({ embeds: [ThailandCodes] });

    await vero.react('✅');

    await vero.react('❌');

  }

});






client.on("messageCreate" , async extra => {

    

if(extra.content.startsWith("!embed")){

if(!extra.member.permissions.has("ADMINISTRATOR")){

  return extra.reply(`**> You Dont Have permission **`)

}

let msg = extra.content.split(" ").slice(1).join(" ")

    if(!msg)return extra.reply(`> ** Put Your Message**`)

  let attach = extra.attachments.first()

  if (attach){

let attachmd = new Discord.MessageEmbed()

  

  .setColor("RED")

  .setDescription(msg)   .setImage(`${attach.url}`)///venomil 

    .setTimestamp()

    
  

   extra.channel.send({embeds: [attachmd]})

  } else {

  let embed = new Discord.MessageEmbed()

  .setTitle(`**__ Venm __**`)

.setDescription(msg)

.setColor("RED") ///venom Devloper

.setTimestamp()



    await extra.channel.send({embeds: [embed]})

   } 

 

   }

 })










client.on('messageCreate', async (message) => {

  if (message.channel.id === '') {// ايدي روم الفيد باك

     if (message.author.bot) return;

    const content = message.content;

    await message.delete();

    const ThailandCodes = new MessageEmbed()

      .setColor('#000000')

      .setDescription(content)

      .setAuthor(message.member.user.tag)

      .addField('-', `Thanks for your feedback, ${message.member.user}!`)

    

.setImage(``)////رابط الخط

      .setTimestamp();

    const vero = await message.channel.send({ embeds: [ThailandCodes] });


await vero.react('❤️');

    await vero.react('🤩');

await vero.react('😍');
  }

});


client.on('messageCreate', async (message) => {
  if (message.content.toLowerCase() === "send") {
    const button = new MessageButton()
      .setStyle("PRIMARY") // طراز الزر
      .setLabel("Open Ticket") // نص الزر
      .setCustomId("ticket_button"); // معرف الزر
      
    const ticketEmbed = new MessageEmbed()
      .setColor("#0099ff")
      .setTitle("New Ticket")
      .setDescription("Click the button below to open a new ticket.");
      
    message.channel.send({ embeds: [ticketEmbed], components: [[button]] });
  }
});

client.on('interactionCreate', async (interaction) => {
  if (!interaction.isButton() || interaction.customId !== "ticket_button") return;

  const category = interaction.guild.channels.cache.find(c => c.type === "GUILD_CATEGORY" && c.name === "Tickets");
  if (!category) return console.log("Tickets category not found.");
  
  await interaction.deferReply();
  
  const ticketChannel = await interaction.guild.channels.create(`ticket-${interaction.user.tag}`, {
    type: "GUILD_TEXT",
    permissionOverwrites: [
      {
        id: interaction.user.id,
        allow: ["VIEW_CHANNEL", "SEND_MESSAGES"]
      },
      {
        id: interaction.guild.roles.everyone,
        deny: ["VIEW_CHANNEL"]
      }
    ],
    parent: category.id
  });
  
  interaction.editReply(`Ticket created! ${ticketChannel}`);
});



client.on('message', async (message) => {

  // (5) Check if the message starts with the "!call" command

  if (message.content.startsWith('!call')) {

    // (6) Get the mentioned user from the message

    const mentionedUser = message.mentions.users.first();

    // (7) Check if a user was mentioned

    if (mentionedUser) {

      // (8) Send a message to the channel, calling the user

      message.channel.send(`Yo ${mentionedUser}, you've been called! :telephone_receiver:`);

    } else {

      // (9) Send a message to the channel, indicating that no user was mentioned

      message.channel.send('You need to mention a user to call them.');

    }

  }

});

