const { SlashCommandBuilder } = require("@discordjs/builders");
const DB = require('../../Schema/Coins/users');
const Canvas = require(`canvas`)
const Discord = require('discord.js');


module.exports = {
    data: new SlashCommandBuilder()
        .setName('transfer')
        .setDescription('تحويل عملات لشخص اخر')
        .addUserOption(option => option
            .setName(`user`)
            .setDescription(`الشخص`)
            .setRequired(true))
        .addIntegerOption(option => option
            .setName(`count`)
            .setDescription(`عدد العملات المراد تحويله`)
            .setRequired(true)),
    run: async (client, interaction, args) => {
        try {
            const user = interaction.options.getUser(`user`);
            const count = interaction.options.getInteger(`count`);

            // Check if the user is trying to transfer to themselves
            if (user.id === interaction.user.id) {
                return interaction.reply({ content: '**لا يمكنك نقل العملات لنفسك.**', ephemeral: true });
            }

            // Check if the user is trying to transfer to another bot
            if (user.bot) {
                return interaction.reply({ content: '**لا يمكنك نقل العملات للبوتات .**', ephemeral: true });
            }

            let authorinfo = await DB.findOne({ userid: interaction.user.id });

            if (!authorinfo) {
                new DB({
                    userid: interaction.user.id,
                }).save();
                return interaction.reply({ content: '**رصيدك غير كافي لاتمام العملية**', ephemeral: true });
            }

            let authorbalance = parseInt(authorinfo.balance);

            if (authorbalance < count) {
                return interaction.reply({ content: '**رصيدك غير كافي لاتمام العملية**', ephemeral: true });
            }



            // Generate a random four-digit code
            const captcha = Math.floor(1000 + Math.random() * 9000);

            const canvas = Canvas.createCanvas(350, 150);
            const ctx = canvas.getContext('2d');
            const background = await Canvas.loadImage('https://www5.0zz0.com/2023/11/28/18/576705137.jpg');
            ctx.drawImage(background, 0, 0, canvas.width, canvas.height);

            ctx.fillStyle = '#D70000';
            ctx.font = 'bold 70px Arial';
            ctx.textAlign = 'center';

            ctx.fillText(`${captcha}`, canvas.width / 2, canvas.height / 2);

            const attachment = new Discord.MessageAttachment(canvas.toBuffer(), 'lfix.png');


            await interaction.reply({ content: `**قم بكتابة الكود الذي يظهر في الصورة لاتمام عملية التحويل**`, files: [attachment] });

            // Set up a filter to check the entered code
            const filter = m => m.author.id === interaction.user.id && m.content === captcha.toString();

            try {
                let receiverinfo = await DB.findOne({ userid: user.id });

                if (!receiverinfo) {
                    new DB({
                        userid: user.id,
                        balance: count,
                    }).save();
    
                    authorinfo.balance = authorbalance - count;
                    // **تم اتمام العملية بنجاح**\nتم تحويل \`${count}\` الى ${user}
                    await user.send(`لقد قام ${interaction.user} بتحويل لك ${count} عملة :coin:`)
                    return interaction.editReply({ content: `قام ${interaction.user} بتحويل ${count} عملة :coin: الى ${user}`, files: [] });
                }
    
                let receiverbalance = parseInt(receiverinfo.balance);
    
                authorbalance -= count;
                receiverbalance += count;
    
                authorinfo.balance = authorbalance;
                receiverinfo.balance = receiverbalance;
    
                authorinfo.save();
                receiverinfo.save();
                // Wait for a response within 30 seconds
                await interaction.channel.awaitMessages({ filter, max: 1, time: 30000, errors: ['time'] });

                await interaction.user.send(`لقد قام ${interaction.user} بتحويل لك ${count} عملة :coin:`)
                    return interaction.editReply({ content: `قام ${interaction.user} بتحويل ${count} عملة :coin: الى ${user}`, files: [] });
            } catch (error) {
                if (error instanceof Map) {
                    // If time runs out, update the reply
                    return interaction.editReply({ content :'**انتهى الوقت. تم إلغاء العملية.**', files: [] });
                } else {
                    throw error;
                }
            }
        } catch (error) {
            console.error(error);
            return interaction.reply({ content: '**حدث خطأ حاول مرة اخرى**', ephemeral: true });
        }
    },
};
