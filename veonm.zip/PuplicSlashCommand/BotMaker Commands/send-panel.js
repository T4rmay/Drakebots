const { SlashCommandBuilder } = require("@discordjs/builders");
const { MessageEmbed, MessageActionRow, MessageButton } = require('discord.js')
const Discord = require('discord.js')
const { Database } = require("st.db");
const config = require("../../config.json");
const owners = require("../../config");

const BOTMAKERDB = new Database("/Json-db/BotMaker/BOTMAKERDB");

module.exports = {
  data: new SlashCommandBuilder()
  .setName('send-panel')
  .setDescription('ارسال قائمة الشراء بالعملات'),
  botPermission: [],
  authorPermission: ["ADMINISTRATOR"],
  ownerOnly: false,
  run: async (client, interaction, args) => {
    try {

          const buybutton = new MessageActionRow().addComponents(
            new MessageButton()
                .setCustomId(`Buy-PP1`)
                .setEmoji('🛒')
                .setLabel(`شراء بوت`)
                .setStyle("SECONDARY"),
            
        );


        const pp1 = new Discord.MessageEmbed()
     .setImage('https://cdn.discordapp.com/attachments/1184542690168279194/1192860915570319461/Picsart_24-01-05_18-02-44-905.jpg?ex=65aa9d4c&is=6598284c&hm=74ab2225817df9a6dabcb6863c732281862a6f7bc402bb018c29d92edcbcdf49&')
        
        .setDescription(` 
## * بانل شراء بوتات ديسكورد جاهزة

## * جميع البوتات اشتراكات شهرية

## * جميع البوتات بنسبة 100‎%‎ اونلاين من دون انقطاع 

## * تاكد ان توكن بوتك صحيح قبل اضافته الى البوت لا تمنشن احد في التكت الا في حدوث خطأ اثناء عملية الشراء يرجى عدم تغيير توكن الخاص ببوتك بعد اكتمال عمليه الشراء تاكد انك مفعل اخر ثلاث خيرات بلبوت ملاحظة : لا نقوم بتغيير توكن البوت من قديم الى جديد

## اسعار البوتات

### * خط تلقائي : 2 كريستاله <:emoji_2:1191103694297636965>

### * اقتراحات : 2 كريستاله <:emoji_2:1191103694297636965>

### * ضريبة برو بوت : 2 كريستاله <:emoji_2:1191103694297636965>

### * كريدت وهمي : 2 كريستاله <:emoji_2:1191103694297636965>

### * تيكت مطور : 2 كريستاله <:emoji_2:1191103694297636965>

### * سيستم : 2 كريستاله <:emoji_2:1191103694297636965>

### * برودكاست : 2 كريستاله <:emoji_2:1191103694297636965>

### * كشف نصابين : 2 كريستاله <:emoji_2:1191103694297636965>

### * جيف اواي : 2 كريستاله <:emoji_2:1191103694297636965>

### * آراء : 2 كريستاله  <:emoji_2:1191103694297636965>

### * لوج : 2 كريستاله <:emoji_2:1191103694297636965>

### * شوب  : 2 كريستاله <:emoji_2:1191103694297636965>

### * برو بوت بريميوم وهمي : 2 كريستاله <:emoji_2:1191103694297636965>

### * كريستال ميكر برايم : 80000 كريدت <:emoji_2:1191103694297636965>

### * كريستال ميكر بريميم : 150000 كريدت <:emoji_2:1191103694297636965>

## * لشراء كريستاله من هنا <#1179878990094274622>  

## واكتب امر /كريستاله 

## * سعر كريستاله <:emoji_2:1191103694297636965> الواحد : 10,000 كريدت مع الضريبة
`)
            .setTitle('Bot Maker');

        await interaction.channel.send({ embeds: [pp1], components: [buybutton] });
        await interaction.reply({ content: 'تم ارسال قائمة الشراء', ephemeral: true })


      
    } catch (error) {
      console.log(error);
      await interaction.reply("حدث خطأ.");
    }
  },
};
