const {
    Client,
    Collection,
    MessageActionRow,
    MessageButton,
    MessageEmbed,
    MessageSelectMenu,
    Intents,
    Modal,
    TextInputComponent
  } = require("discord.js");
  const { ChannelType } = require("discord-api-types/v9");
  const Discord = require('discord.js');
  const { SlashCommandBuilder } = require("@discordjs/builders")

const { Database } = require("st.db");
const BOTMAKERDB = new Database("/Json-db/BotMaker/BOTMAKERDB");
  
  module.exports = {
    data: new SlashCommandBuilder()
      .setName(`setup`)
      .setDescription(`ضبط اعدادت البوت`)
        .addChannelOption(ch =>ch
            .setName(`ticket-category`)
            .setDescription(`Select the category for BotMaker tickets`)
            .addChannelTypes(ChannelType.GuildCategory)
            .setRequired(true)),
    botPermission: [""],
    authorPermission: ["ADMINISTRATOR"],
    ownerOnly: false,
    async run(client, interaction) {
      try {
        const botmakercategory = interaction.options.getChannel('ticket-category').id
        const onecoinsprice = interaction.options.getString(`coins-price`)

        BOTMAKERDB.set(`BotMakerTicket_${interaction.guild.id}`, {
            Category: botmakercategory,
          })
                 .then(async () => {
            await interaction.reply('Setuped BotMaker Successfully');
          });
      } catch (error) {
        console.log(error)
        await interaction.reply(`حدث خطا`)
      }
    },
  };
