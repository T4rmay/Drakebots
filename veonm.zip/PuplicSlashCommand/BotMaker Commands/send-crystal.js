const { SlashCommandBuilder } = require("@discordjs/builders");
const { MessageEmbed, MessageActionRow, MessageButton } = require('discord.js')
const Discord = require('discord.js')
const { Database } = require("st.db");
const config = require("../../config.json");
const owners = require("../../config");

const BOTMAKERDB = new Database("/Json-db/BotMaker/BOTMAKERDB");

module.exports = {
  data: new SlashCommandBuilder()
  .setName('send-crystal')
  .setDescription('ارسال قائمة كريستاله'),
  botPermission: [],
  authorPermission: ["ADMINISTRATOR"],
  ownerOnly: false,
  run: async (client, interaction, args) => {
    try {

          const buybutton = new MessageActionRow().addComponents(
                    new MessageButton()
                .setCustomId(`my-coins`)
                .setEmoji('<:emoji_2:1191103694297636965>')
                .setLabel(`كريستاله`)
                .setStyle("SECONDARY")
           );



        const pp1 = new Discord.MessageEmbed()
     .setImage('https://cdn.discordapp.com/attachments/1184542690168279194/1195110738457530490/Picsart_24-01-11_23-02-51-095.png?ex=65b2cc9c&is=65a0579c&hm=d7175cef51cabdc43ff48941f5ca536a618d8bbdd2b4adecf3c50fed4ee44538&')
        
        .setDescription(` 
لمعرفه عدد الكريستاله الي معاك <:emoji_2:1191103694297636965>

`)
            .setTitle('crystal');

        await interaction.channel.send({ embeds: [pp1], components: [buybutton] });
        await interaction.reply({ content: 'تم ارسال قائمة كريستاله', ephemeral: true })


      
    } catch (error) {
      console.log(error);
      await interaction.reply("حدث خطأ.");
    }
  },
};
