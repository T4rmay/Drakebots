const { SlashCommandBuilder } = require("@discordjs/builders");
const DB = require('../../Schema/Coins/users');

module.exports ={
    data: new SlashCommandBuilder()
    .setName('coins')
    .setDescription('معرفة عدد الكريستاله  الخاصه بيك او بعضو اخر')
    .addUserOption(Option => Option
        .setName(`user`)
        .setDescription(`العضو`)
        .setRequired(false)),

    run: async (client, interaction, args) => {
        try {
            const sent = await interaction.deferReply({ fetchReply: true });
            let userr = interaction.options.getUser(`user`)

            if(!userr) {
            const user = await DB.findOne({userid:interaction.user.id})
            if(!user) {
                new DB({
                    userid:interaction.user.id,
                }).save()
                return interaction.editReply({ content: `**رصيدك هو : \`0\`**` })
            }
            let balance = user.balance
                return interaction.editReply({ content: `**رصيدك هو : \`${balance}\` <:emoji_2:1191103694297636965> **` })
        }
        if(userr) {
            const user = await DB.findOne({userid:userr.id})
            if(!user) {
                new DB({
                    userid:userr.id,
                }).save()
                return interaction.editReply({ content: `**رصيد ${userr} هو : \`0\`**` })
            }
            let balance = user.balance
                return interaction.editReply({ content: `**رصيد ${userr} هو : \`${balance}\` <:emoji_2:1191103694297636965> **` })
        }
        } catch (error) {
            return interaction.editReply({content:`**حدث خطأ حاول مرة اخرى**`})
        }
       
            
    }
}