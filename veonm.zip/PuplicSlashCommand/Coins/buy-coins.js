const { SlashCommandBuilder } = require("@discordjs/builders");
const { MessageEmbed } = require("discord.js");
const { Database } = require("st.db");
const db = require('../../Schema/Coins/users');
const BOTMAKETDB = new Database('/Json-db/BotMaker/BOTMAKERDB.json');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('شراء-العملات')
        .setDescription('شراء العملات بالكريديت'),

    run: async (client, interaction) => {
        const allowedRoomId = '1179878990094274622'; // استبدل بمعرف الروم الذي يمكن فيه استخدام الأمر

        if (interaction.channelId !== allowedRoomId) {
            return interaction.reply('**لا يمكنك استخدام هذا الأمر في هذا الروم**');
        }

        const Price = BOTMAKETDB.get(`Price_${interaction.guild.id}`);
        const Owner = BOTMAKETDB.get(`trID_${interaction.guild.id}`);
        const ProbotID = BOTMAKETDB.get(`probotID_${interaction.guild.id}`);
        const embed = new MessageEmbed()
            .setColor('#0099ff')
            .setTitle('شراء العملات')
            .setDescription('من فضلك، اكتب عدد العملات المطلوب شراؤها.')

        interaction.reply({ embeds: [embed] }).then(async () => {
            try {
                const collected = await interaction.channel.awaitMessages({
                    filter: ({ content, author: { id } }) => id === interaction.user.id,
                    max: 1,
                    time: 60000,
                    errors: ['time']
                });

                if (collected.size > 0) {
                    const quantityToBuy = parseInt(collected.first().content);
                    const price = quantityToBuy * Price;
                    const tax = Math.floor(price * (20 / 19) + 1);

                    interaction.editReply({ content: `\`\`\`#credit ${Owner} ${tax}\`\`\`` });

                    const response = await interaction.channel.awaitMessages({
                        filter: ({ content, author: { id } }) => {
                            return content.startsWith(`**:moneybag: | ${interaction.user.username}, has transferred `) &&
                                content.includes(`${Owner}`) &&
                                id === `${ProbotID}` &&
                                (Number(content.slice(content.lastIndexOf("`") - String(tax).length, content.lastIndexOf("`"))) >= price);
                        },
                        max: 1,
                        time: 60000,
                        errors: ['time']
                    });

                    if (response.size > 0) {
                        const userBalance = await db.findOne({ userid: interaction.user.id });

                        if (userBalance) {
                            const updatedBalance = parseInt(userBalance.balance) + parseInt(quantityToBuy);
                            await db.findOneAndUpdate({ userid: interaction.user.id }, { balance: updatedBalance });
                        } else {
                            const newUser = new db({
                                userid: interaction.user.id,
                                balance: quantityToBuy,
                            });
                            await newUser.save();
                        }

                        interaction.editReply({ content: `**لقد قام ${interaction.user} بشراء ${quantityToBuy} العملات** ` });

                        response.first().delete();
                    }
                }
            } catch (error) {
                interaction.editReply({ content: `**انتهى الوقت لا تقم بالتحويل ** ${interaction.user}` });
            }
        });
    },
};
