const config = require("../config.js");
const { Permissions, MessageEmbed, MessageActionRow, MessageSelectMenu } = require("discord.js");
const { Database } = require("st.db");
const config3 = require("../config.json");
const owners = require("../config");
const DB = require('../Schema/Coins/users');

const BOTMAKERDB = new Database("/Json-db/BotMaker/BOTMAKERDB");

module.exports.run = async (client, interaction) => {

  if (interaction.isCommand()) {
    const { commandName, options, user, guildId } = interaction;

    const command = await client.slashcommands.get(commandName) || await client.Guildcommands.get(commandName)
    if (!command) return;
    if (command.ownerOnly === true) {
      if (!config.owners.includes(interaction.user.id)) {
        return interaction.reply({ content: `❗ ***لا تستطيع استخدام هذا الامر***`, ephemeral: true });
      }
    }

    if (command.botPermission) {
      const missingPermissions = [];
      const botPermissions = interaction.guild.members.me.permissions;

      if (command.botPermission && Array.isArray(command.botPermission)) {
        command.botPermission.forEach((permission) => {
          if (!botPermissions.has(permission)) {
            missingPermissions.push(permission);
          }
        });
      }
      if (missingPermissions.length) {
        const missingPermsEmbed = new MessageEmbed()
          .setColor("#ff0000")
          .setDescription(`❌ I don't have the required permissions: ${missingPermissions.join(", ")}`);

        return interaction.reply({ embeds: [missingPermsEmbed], ephemeral: true });
      }
    }

    if (command.authorPermission) {
      const missingPermissions = [];
      const memberPermissions = interaction.member.permissions;

      command.authorPermission.forEach((permission) => {
        if (!memberPermissions.has(permission)) {
          missingPermissions.push(permission);
        }
      });

      if (missingPermissions.length) {
        const missingPermsEmbed = new MessageEmbed()
          .setColor("#ff0000")
          .setDescription(`❌ You don't have the required permissions: ${missingPermissions.join(", ")}`);

        return interaction.reply({ embeds: [missingPermsEmbed], ephemeral: true });
      }
    }


    try {
      if (command) {
        command.run(client, interaction);
      }
    } catch (error) {
      console.error(`Error executing command ${commandName}:`, error);
    }
  }
  //Button Hanlder
  else if (interaction.isButton()) {
    const customId = interaction.customId;
    if (customId === 'my-coins') {
      const user = await DB.findOne({ userid: interaction.user.id });
      if (!user) {
        new DB({ userid: interaction.user.id }).save();
        interaction.reply({ content: '<:emoji_2:1191103694297636965> لديك 0 كريستاله', ephemeral: true });
      } else {
        let balance = user.balance;
        interaction.reply({ content: `لديك ${balance} كريستاله <:emoji_2:1191103694297636965>`, ephemeral: true });
      }

    } else if (customId === 'Buy-PP1'){
      if (interaction.guild.id === '1179878986952740884') {
        const data = BOTMAKERDB.get(`BotMakerTicket_${interaction.guild.id}`);
  const Bot_Selector_ofc = new MessageActionRow().addComponents(
    new MessageSelectMenu()
      .setCustomId("BOTMAKER_Selector")
      .setPlaceholder("اختار بوتك الان ")
      .setOptions([
        {
          label: "خط تلقائي",
          value: "Autoline_Selected",
            emoji: '<:emoji_41:1194710363409756181>',
          description: "To create a new autoline bot",
        },
        {
          label: "اقتراحات",
          value: "Suggestion_Selected",
           emoji: '<:emoji_21:1194710317498908762>', 
          description: "To create new suggestion bot",
        },
        {
          label: "ضريبة بروبوت",
          value: "Tax_Selected",
          emoji: '<:emoji_19:1194710312222474370>',
          description: "To create new Auto tax bot",
        },
        {
          label: "كريديت وهمي",
          value: "Credit_Selected",
          emoji: '<:emoji_18:1194710309735243806>',
          description: "To create new Fake-Credit bot",
        },
        {
          label: "تيكت مطور",
          value: "Ticket_Selected",
          emoji: '<:emoji_151:1194710303817072713>',
          description: "To create new Ticket bot",
        },
        {
          label: "سيستم",
          value: "System_Selected",
          emoji: '<:emoji_2:1194710246585794641>',
          description: "To create new System bot",
        },
        {
          label: "برودكاست",
          value: "Brodcast_Selected",
          emoji: '<:emoji_29:1194710338713686057>',
          description: "To create new Brodcast bot",
        },
        {
          label: "كشف نصابين",
          value: "Scammers_Selected",
          emoji: '<:emoji_41:1194710252285870161>',
          description: "To create new Scammers bot",
        },
        {
          label: "جيف اواي",
          value: "Giveaway_Selected",
          emoji: '<:emoji_331:1194710352018014340>',
          description: "To create new Giveaway bot",
        },
        {
          label: "بروبوت بريميوم وهمي",
          value: "Probot_selected",
          emoji: '<:emoji_28:1194710332174761994>',
          description: "To create new Fake Probot Premuim bot",
        },
        {
          label: "اراء",
          value: "Feedback_selected",
          emoji: '<:emoji_311:1194710346850648214>',
          description: "To create new Feedback bot",
        },
        {
          label: "لوج",
          value: "Logs_selected",
          emoji: '<:emoji_15:1194710299907993670>',
          description: "To create new Logger bot",
        },
        {
          label: "سيستم شوب",
          value: "Shop_selected",
          emoji: '<:emoji_211:1194710319411499008>',
          description: "To create new Shop bot",
         },   {

                label: "كريستال ميكر برايم",

                value: "BOTMAKER_Tier2_Selected",

                emoji: '<:emoji_45:1195465050509557842>',

                description: "اشتراك ميكر برايم سعر الاشتراك ب الكريدت",

              },

              {

                label: "كريستال ميكر بريميم",

                value: "BOTMAKER_Tier3_Selected",

                emoji: '<:emoji_44:1195464938873966632>',

                description: "اشتراك ميكر بريميم سعر الاشتراك ب الكريدت",

              },
        {
          label: "Reset",
          value: "Reset_Selected",
          emoji: '<a:ss_4:1177710962363617420>',
          description: "لتحديث المنيو",
        },
      ])
  );
        interaction.reply({ components: [Bot_Selector_ofc], ephemeral: true })
      } else {
        const data = BOTMAKERDB.get(`BotMakerTicket_${interaction.guild.id}`);
  const Bot_Selector_sub = new MessageActionRow().addComponents(
    new MessageSelectMenu()
      .setCustomId("BOTMAKER_Selector")
      .setPlaceholder("اختار بوتك الان ")
      .setOptions([
        {

          label: "خط تلقائي",

          value: "Autoline_Selected",
            
          emoji: '<:emoji_41:1194710363409756181>',

          description: "To create a new autoline bot",

        },

        {

          label: "اقتراحات",

          value: "Suggestion_Selected",

          emoji: '<:emoji_21:1194710317498908762>',
            
          description: "To create new suggestion bot",

        },

        {

          label: "ضريبة بروبوت",

          value: "Tax_Selected",
            
          emoji: '<:emoji_19:1194710312222474370>',

          description: "To create new Auto tax bot",

        },

        {

          label: "كريديت وهمي",

          value: "Credit_Selected",
            
          emoji: '<:emoji_18:1194710309735243806>',

          description: "To create new Fake-Credit bot",

        },
          {
          label: "تيكت مطور",
          value: "Ticket_Selected",
          emoji: '<:emoji_151:1194710303817072713>',
          description: "To create new Ticket bot",
        },
        {
          label: "سيستم",
          value: "System_Selected",
          emoji: '<:emoji_2:1194710246585794641>',
          description: "To create new System bot",
        },
        {
          label: "برودكاست",
          value: "Brodcast_Selected",
          emoji: '<:emoji_29:1194710338713686057>',
          description: "To create new Brodcast bot",
        },
        {
          label: "كشف نصابين",
          value: "Scammers_Selected",
          emoji: '<:emoji_41:1194710252285870161>',
          description: "To create new Scammers bot",
        },
          {

          label: "جيف اواي",

          value: "Giveaway_Selected",

          emoji: '<:emoji_331:1194710352018014340>',
              
          description: "To create new Giveaway bot",

        },
        {
          label: "بروبوت بريميوم وهمي",
          value: "Probot_selected",
          emoji: '<:emoji_28:1194710332174761994>',
          description: "To create new Fake Probot Premuim bot",
        },
          {

          label: "اراء",

          value: "Feedback_selected",

         emoji: '<:emoji_311:1194710346850648214>',
              
          description: "To create new Feedback bot",

        },
        {
          label: "لوج",
          value: "Logs_selected",
           emoji: '<:emoji_15:1194710299907993670>',
          description: "To create new Logger bot",
        },
        {
          label: "سيستم شوب",
          value: "Shop_selected",
          emoji: '<:emoji_211:1194710319411499008>',
          description: "To create new Shop bot",
        }, {

                label: "كريستال ميكر برايم",

                value: "BOTMAKER_Tier2_Selected",

                emoji: '<:emoji_45:1195465050509557842>',

                description: "اشتراك ميكر برايم سعر الاشتراك ب الكريدت",

              },

              {

                label: "كريستال ميكر بريميم",

                value: "BOTMAKER_Tier2_Selected",

                emoji: '<:emoji_44:1195464938873966632>',

                description: "اشتراك ميكر بريميم سعر الاشتراك ب الكريدت",


              },
          {
          label: "Reset",
          value: "Reset_Selected",
          emoji: '<a:ss_4:1177710962363617420>',
          description: "لتحديث المنيو",
        },
      ])
  );
        interaction.reply({ components: [Bot_Selector_sub], ephemeral: true })
      }
    }
    const button = await client.buttons.get(interaction.customId);
    if (!button) return;
    if (button.ownerOnly === true) {
      if (!config.owners.includes(user.id)) {
        return interaction.reply({ content: `❗ ***لا تستطيع استخدام هذا الزر***`, ephemeral: true });
      }
    }

    if (button.botPermission) {
      const missingPermissions = [];
      const botPermissions = interaction.guild.me.permissions;

      if (button.botPermission && Array.isArray(button.botPermission)) {
        button.botPermission.forEach((permission) => {
          if (!botPermissions.has(permission)) {
            missingPermissions.push(permission);
          }
        });
      }
      if (missingPermissions.length) {
        const missingPermsEmbed = new MessageEmbed()
          .setColor("#ff0000")
          .setDescription(`❌ I don't have the required permissions: ${missingPermissions.join(", ")}`);

        return interaction.reply({ embeds: [missingPermsEmbed], ephemeral: true });
      }
    }

    if (button.authorPermission) {
      const missingPermissions = [];
      const memberPermissions = interaction.member.permissions;

      button.authorPermission.forEach((permission) => {
        if (!memberPermissions.has(permission)) {
          missingPermissions.push(permission);
        }
      });

      if (missingPermissions.length) {
        const missingPermsEmbed = new MessageEmbed()
          .setColor("#ff0000")
          .setDescription(`❌ You don't have the required permissions: ${missingPermissions.join(", ")}`);

        return interaction.reply({ embeds: [missingPermsEmbed], ephemeral: true });
      }
    }

    try {
      if (button) {
        button.run(client, interaction);
      }
    } catch (error) {
      console.error(`Error executing button ${customId}:`, error);
    }
  }
  //SelectMenu Handler
  else if (interaction.isSelectMenu()) {
    const selectMenu = await client.selectMenus.get(interaction.customId);
    if (!selectMenu) return;

    if (selectMenu.ownerOnly === true) {
      if (!config.owners.includes(user.id)) {
        return interaction.reply({ content: `❗ ***لا تستطيع استخدام هذا القائمة***`, ephemeral: true });
      }
    }

    if (selectMenu.botPermission) {
      const missingPermissions = [];
      const botPermissions = interaction.guild.me.permissions;

      if (selectMenu.botPermission && Array.isArray(selectMenu.botPermission)) {
        selectMenu.botPermission.forEach((permission) => {
          if (!botPermissions.has(permission)) {
            missingPermissions.push(permission);
          }
        });
      }
      if (missingPermissions.length) {
        const missingPermsEmbed = new MessageEmbed()
          .setColor("#ff0000")
          .setDescription(`❌ I don't have the required permissions: ${missingPermissions.join(", ")}`);

        return interaction.reply({ embeds: [missingPermsEmbed], ephemeral: true });
      }
    }

    if (selectMenu.authorPermission) {
      const missingPermissions = [];
      const memberPermissions = interaction.member.permissions;

      selectMenu.authorPermission.forEach((permission) => {
        if (!memberPermissions.has(permission)) {
          missingPermissions.push(permission);
        }
      });

      if (missingPermissions.length) {
        const missingPermsEmbed = new MessageEmbed()
          .setColor("#ff0000")
          .setDescription(`❌ You don't have the required permissions: ${missingPermissions.join(", ")}`);

        return interaction.reply({ embeds: [missingPermsEmbed], ephemeral: true });
      }
    }

    try {
      if (selectMenu) {
        selectMenu.run(client, interaction);
      }
    } catch (error) {
      console.error(`Error executing select menu ${customId}:`, error);
    }
  }
  //Modal
  else if (interaction.isModalSubmit()) {
    const selectMenu = await client.modlas.get(interaction.customId);
    if (!selectMenu) return;

    if (selectMenu.ownerOnly === true) {
      if (!config.owners.includes(user.id)) {
        return interaction.reply({ content: `❗ ***لا تستطيع استخدام هذا القائمة***`, ephemeral: true });
      }
    }

    if (selectMenu.botPermission) {
      const missingPermissions = [];
      const botPermissions = interaction.guild.me.permissions;

      if (selectMenu.botPermission && Array.isArray(selectMenu.botPermission)) {
        selectMenu.botPermission.forEach((permission) => {
          if (!botPermissions.has(permission)) {
            missingPermissions.push(permission);
          }
        });
      }
      if (missingPermissions.length) {
        const missingPermsEmbed = new MessageEmbed()
          .setColor("#ff0000")
          .setDescription(`❌ I don't have the required permissions: ${missingPermissions.join(", ")}`);

        return interaction.reply({ embeds: [missingPermsEmbed], ephemeral: true });
      }
    }

    if (selectMenu.authorPermission) {
      const missingPermissions = [];
      const memberPermissions = interaction.member.permissions;

      selectMenu.authorPermission.forEach((permission) => {
        if (!memberPermissions.has(permission)) {
          missingPermissions.push(permission);
        }
      });

      if (missingPermissions.length) {
        const missingPermsEmbed = new MessageEmbed()
          .setColor("#ff0000")
          .setDescription(`❌ You don't have the required permissions: ${missingPermissions.join(", ")}`);

        return interaction.reply({ embeds: [missingPermsEmbed], ephemeral: true });
      }
    }

    try {
      if (selectMenu) {
        selectMenu.run(client, interaction);
      }
    } catch (error) {
      console.error(`Error executing select menu ${customId}:`, error);
    }
  }
  else{
    return;
  }

}
