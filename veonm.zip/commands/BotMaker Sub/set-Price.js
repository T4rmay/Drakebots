const Discord = require('discord.js');
const { Database } = require('st.db');
const BOTMAKETDB = new Database('/Json-db/BotMaker/BOTMAKERDB.json');

module.exports = {
    name: 'set-coinsprice',
    aliases: [''],
    description: '',
    usage: [''],
    botPermission: [''],
    authorPermission: ['ADMINISTRATOR'],
    cooldowns: [],
    ownerOnly: false,
    run: async (client, message, args, config) => {
        const ownerID = BOTMAKETDB.get(`trID_${message.guild.id}`);
        const price = BOTMAKETDB.get(`Price_${message.guild.id}`);

        if (!message.author.id === ownerID && !message.author.id === '1148933797346279484') {
            return message.reply('انت لست مالك البوت');
        }

        let newprice = args[0];

        if (!newprice) {
            return message.reply('قم بتحديد سعر العملة الواحدة');
        }

        if (isNaN(newprice)) {
            return message.reply('قم بتحديد سعر العملة الواحدة');
        }

        message.reply(`سعر العملات الجديد هو ${newprice}`);
        BOTMAKETDB.set(`Price_${message.guild.id}`, newprice);
    },
};
